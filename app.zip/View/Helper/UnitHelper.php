<?php

/**
 * @Amit Sahu
 *
 */
App::uses('Helper', 'View');

class UnitHelper extends AppHelper {

  /*  function getItemStockLocationWise($conditions,$field) {

        $this->Stock = ClassRegistry::init('Stock');
		$items=$this->Stock->getallStock($conditions,$field);
		return $items;
    }*/
	 function change($item_id=NULL, $value=NULL,$unit=NULL){
      
		$this->Item = ClassRegistry::init('Item');
		  $itemdata=$this->Item->find('first',array('conditions'=>array('Item.id'=>$item_id),'fields'=>array('Item.unit','Item.alt_unit','Item.id'),'contain'=>array()));
				$changeValue['qty']=$value;
			  $changeValue['unit']=$unit;
		  if(!empty($itemdata))
		  {
			  if(!empty($itemdata['Item']['alt_unit']))
			  {
				  if($itemdata['Item']['alt_unit']==$unit)
				  {
					  $this->Unit = ClassRegistry::init('Unit');
						$unitdata=$this->Unit->findById($unit);
						  $changeValue['qty']=$value/$unitdata['Unit']['alt_clac'];
						  $changeValue['unit']=$itemdata['Item']['unit'];
					
				  }
				 
			  }else{
				  $changeValue['qty']=$value;
				   $changeValue['unit']=$unit;
			  }
		  }else{
			  $changeValue['qty']=$value;
			  $changeValue['unit']=$unit;
		  }
		  
		  
		 return $changeValue; 
    }
	 function changeReverse($item_id=NULL, $value=NULL,$unit=NULL){
			$this->Item = ClassRegistry::init('Item');
		  $itemdata=$this->Item->find('first',array('conditions'=>array('Item.id'=>$item_id),'fields'=>array('Item.unit','Item.alt_unit','Item.id'),'contain'=>array()));
				$changeValue['qty']=$value;
			  $changeValue['unit']=$unit;
	
			  if(!empty($itemdata['Item']['alt_unit']))
			  {
				  if($itemdata['Item']['unit']==$unit)
				  {
					  $this->Unit = ClassRegistry::init('Unit');
						$unitdata=$this->Unit->findById($itemdata['Item']['alt_unit']);
						
						  $changeValue['qty']=$value*$unitdata['Unit']['alt_clac'];
						 
						  $changeValue['unit']=$itemdata['Item']['alt_unit'];
					
				  }
			  }else{
				  $changeValue['qty']=$value;
				   $changeValue['unit']=$unit;
			  }
		 
		  
		  
		 return $changeValue; 
    }

	/*
	Purchase Edit Item wise unit
	Amit Sahu
	04.10.17
	*/
	function getUnitListItemWise($item_id=NULL){
		
		$this->Item = ClassRegistry::init('Item');
		$itemData=$this->Item->find('first',array('conditions'=>array('Item.id'=>$item_id),'fields'=>(''),'contain'=>array('Unit'=>array('code','id'),'AltUnit'=>array('code','id'))));
		return $itemData;
	}
	
}
