<?php

/**
 * @Amit Sahu
 *
 */
App::uses('Helper', 'View');

class ItemHelper extends AppHelper {

    function getItemStockLocationWise($conditions,$field) {

        $this->Stock = ClassRegistry::init('Stock');
		$items=$this->Stock->getallStock($conditions,$field);
		return $items;
    }
	
	
	function getIternaOrderItem($conditions,$field) {
        $this->InternalOrderDetails = ClassRegistry::init('InternalOrderDetails');
		$per=$this->InternalOrderDetails->getAllUserNavPermission($conditions,$field);
		return $per;
    }

	function countUnreadIntOrder() {
        $this->InternalPorder = ClassRegistry::init('InternalPorder');
		$IntorderCount=$this->InternalPorder->countUnreadIntOrder();
		return $IntorderCount;
    }

   function dispatchItemPoAgainst($conditions,$fields) {
        $this->InternalOrderDetails = ClassRegistry::init('InternalOrderDetails');
		$dispatchQty=$this->InternalOrderDetails->getAllInternalOrderitem($conditions,$fields);
		return $dispatchQty;
    }

   function getUnitList($unit) {
        $this->Unit = ClassRegistry::init('Unit');
		$unitList=$this->Unit->getMultiUnitList($unit);
		return $unitList;
    }  

}
