-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 12, 2016 at 04:33 PM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nms`
--

-- --------------------------------------------------------

--
-- Table structure for table `area_units`
--

CREATE TABLE IF NOT EXISTS `area_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `area_units`
--

INSERT INTO `area_units` (`id`, `name`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Square kilometre', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(2, 'Square metre', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(3, 'Square mile', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(4, 'Square yard', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(5, 'Square foot', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(6, 'Square inch', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(7, 'Hectare', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00'),
(8, 'Acre', 1, 0, '2016-07-09 00:00:00', '2016-07-09 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_district` tinyint(1) NOT NULL,
  `state_id` int(10) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_deleted` int(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `is_district`, `state_id`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Mumbai', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(2, 'Pune', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(3, 'Nagpur', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(4, 'Thane', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(5, 'Nashik', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(6, 'Palghar', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(7, 'Aurangabad', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(8, 'Navi Mumbai', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(9, 'Solapur', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(10, 'Amravati', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(11, 'Nanded', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(12, 'Kolhapur', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(13, 'Sangli', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(14, 'Jalgaon', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(15, 'Akola', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(16, 'Latur', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(17, 'Malegaon', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(18, 'Dhule', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(19, 'Ahmednagar', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(20, 'Chandrapur', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07'),
(21, 'Parbhani', 1, 20, 1, 0, '2016-06-15 15:25:07', '2016-06-15 15:25:07');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `mobile_no`, `message`, `ip_address`, `created`, `modified`) VALUES
(1, 'Masood', 'masood@gmail.com', '8055736852', 'Hello , This is test message', '', '2016-06-29 12:06:31', '2016-06-29 12:06:31'),
(2, 'Masood', 'masood@gmail.com', '8055736852', 'sdsdsdssa', '127.0.0.1', '2016-06-29 12:08:13', '2016-06-29 12:08:13'),
(3, 'Masood', 'masood@gmail.com', '8055736852', 'Hello , I want to register but how', '127.0.0.1', '2016-06-29 12:22:25', '2016-06-29 12:22:25'),
(4, 'Masood', 'masood@gmail.com', '8055736852', 'Hello , This is test mail from masood', '127.0.0.1', '2016-06-29 12:27:16', '2016-06-29 12:27:16'),
(5, 'Masood', 'masood@gmail.com', '8055736852', 'zdcfdds dsfsdf dsfsdf sdfdsfdsf sdf sdfsdfsdf sdfsdfsf zdcfdds dsfsdf dsfsdf sdfdsfdsf sdf sdfsdfsdf sdfsdfsf zdcfdds dsfsdf dsfsdf sdfdsfdsf sdf sdfsdfsdf sdfsdfsf zdcfdds dsfsdf dsfsdf sdfdsfdsf sdf sdfsdfsdf sdfsdfsf zdcfdds dsfsdf dsfsdf sdfdsfdsf sdf sdfsdfsdf sdfsdfsf ', '127.0.0.1', '2016-06-29 12:31:41', '2016-06-29 12:31:41');

-- --------------------------------------------------------

--
-- Table structure for table `content_translations`
--

CREATE TABLE IF NOT EXISTS `content_translations` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `content_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `content_translations`
--

INSERT INTO `content_translations` (`id`, `content_id`, `name`, `content`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 1, 'à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚', '<p><span class="short_text" id="result_box" lang="hi"><span class="hps">à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ à¤¹à¤®à¤¾à¤°à¥‡ à¤¬à¤¾à¤°à¥‡ à¤®à¥‡à¤‚</span> <span class="hps">à¤µà¤¿à¤µà¤°à¤£</span> <span class="hps">à¤ªà¤¾à¤ </span></span></p>\r\n', 1, 0, '2015-10-17 18:26:27', '2016-03-04 12:17:39');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `country_code` varchar(20) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_deleted` int(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `country_code`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'India', '', 1, 0, '2016-06-04 17:23:33', '2016-06-04 17:23:33');

-- --------------------------------------------------------

--
-- Table structure for table `customer_packages`
--

CREATE TABLE IF NOT EXISTS `customer_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `validity` int(11) NOT NULL,
  `cost` float(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customer_packages`
--

INSERT INTO `customer_packages` (`id`, `name`, `description`, `validity`, `cost`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Free', '<p>sddasas asd</p>\r\n\r\n<p>asdas dasdas</p>\r\n\r\n<p>asda as</p>\r\n', 0, 0.00, 1, 0, '2016-06-07 12:31:19', '2016-06-07 12:31:19'),
(2, 'Basic', '<p>dffdsf</p>\r\n', 30, 500.00, 1, 0, '2016-06-07 12:12:16', '2016-06-07 12:28:55'),
(3, 'Premium', '<p>DSDDSDSF<br />\r\nDSDDSDSF<br />\r\nDSDDSDSF<br />\r\nDSDDSDSF<br />\r\n&nbsp;</p>\r\n', 90, 1000.00, 1, 0, '2016-06-07 12:07:59', '2016-06-07 12:29:16'),
(4, 'Professional', '<p>asdd da asda asd</p>\r\n\r\n<p>asdadsa asda asd</p>\r\n\r\n<p>asdsa asd asd dadasdas</p>\r\n', 180, 2000.00, 1, 0, '2016-06-07 12:29:38', '2016-06-07 12:29:38');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL COMMENT 'name of email template',
  `subject` varchar(255) NOT NULL COMMENT 'subject of email template',
  `content` text NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0 => inactive/1 => active',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 => not deleted/1 => deleted',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_templates_id_UNIQUE` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `type`, `subject`, `content`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Customer Registration', 'Registration Successfull', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px solid #333;">\r\n<div style="background:#3c8dbc;padding:5px;border-bottom:1px solid #333;">\r\n<h3 style="color:#FFF;font-weight:bold;">Registration Successfull</h3>\r\n</div>\r\n\r\n<div style="width:100%;float:left;background:#ecf0f5;">\r\n<div style="width:98%;float:left;padding:10px;"><strong>Dear <span style="color:#A52A2A;">[CUSTOMER_NAME]</span>,</strong>\r\n\r\n<p>Your registration with notice management has been completed . verify youe email by clicking on the below link.</p>\r\n\r\n<div style="width:100%;color:#333333">\r\n<p><span style="font-size:18px;"><strong>Account Detail</strong></span></p>\r\n\r\n<p><span style="color:#800000;">[EMAIL]</span></p>\r\n\r\n<p><span style="color:#800000;">[PASSWORD]</span></p>\r\n\r\n<div align="center" style="padding:10px;">[VERIFICATION_LINK]</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div align="center">&copy; <a href="http://www.trackproperty.in">www.trackproperty.in</a></div>\r\n</div>\r\n</div>\r\n', 1, 0, '2016-06-08 11:49:01', '2016-06-23 13:45:22'),
(2, 'Forgot Password', 'Password Reset Link', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px solid #333;">\r\n<div style="background:#3c8dbc;padding:5px;border-bottom:1px solid #333;">\r\n<h3 style="color:#FFF;font-weight:bold;">Rest Password</h3>\r\n</div>\r\n\r\n<div style="width:100%;float:left;background:#ecf0f5;">\r\n<div style="width:98%;float:left;padding:10px;"><strong>Dear <span style="color:#A52A2A;">[CUSTOMER_NAME]</span>,</strong>\r\n\r\n<p>You have requested to reset your password ,here is your password reset link. Click on the below link to reset your password.</p>\r\n\r\n<div style="width:100%;color:#333333">\r\n<div align="center" style="padding:10px;">[PASSWORD_RESET_LINK]</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div align="center">&copy; <a href="http://www.trackproperty.in">www.trackproperty.in</a></div>\r\n</div>\r\n</div>\r\n', 1, 0, '2016-06-17 12:45:48', '2016-06-23 14:30:18'),
(3, 'Account Activation Mail', 'Activate Your Account', '<p>dsd</p>\r\n', 0, 1, '2016-06-18 16:42:46', '2016-06-18 16:44:59'),
(4, 'Match Alert Mail', 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px solid #333;">\r\n<div style="background:#3c8dbc;padding:5px;border-bottom:1px solid #333;">\r\n<h3 style="color:#FFF;font-weight:bold;">Notice Alert</h3>\r\n</div>\r\n\r\n<div style="width:100%;float:left;background:#ecf0f5;">\r\n<div style="width:98%;float:left;padding:10px;"><strong>Dear <span style="color:#A52A2A;">[CUSTOMER_NAME]</span>,</strong>\r\n\r\n<p>This is to inform you that your one of the registered property may have notice. The given notice is matching with your property .</p>\r\n\r\n<div style="width:100%;color:#333333">\r\n<h4><u>Notice Detail</u></h4>\r\n\r\n<table border="1" bordercolor="#0033CC" cellpadding="3" cellspacing="0">\r\n	<tbody>\r\n		<tr>\r\n			<td width="40%"><strong>Notice Date</strong></td>\r\n			<td width="10%">:</td>\r\n			<td width="50%">[NOTICE_DATE]</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="40%"><strong>Notice Type</strong></td>\r\n			<td width="10%">:</td>\r\n			<td width="50%">[NOTICE_TYPE]</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="40%"><strong>News Paper</strong></td>\r\n			<td width="10%">:</td>\r\n			<td width="50%">[NEWS_PAPER]</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="40%"><strong>Page Number</strong></td>\r\n			<td width="10%">:</td>\r\n			<td width="50%">[PAGE_NO]</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="40%"><strong>Notice Period</strong></td>\r\n			<td width="10%">:</td>\r\n			<td width="50%">[NOTICE_PERIOD]</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="40%"><strong>Notice Last Date</strong></td>\r\n			<td width="10%">:</td>\r\n			<td width="50%">[NOTICE_LAST_DATE]</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n\r\n<div style="width:100%;color:#333333">\r\n<div style="width: 50%;float: left;">\r\n<h4><u>Noticed Property</u></h4>\r\n\r\n<table border="1" bordercolor="#0033CC" cellpadding="3" cellspacing="0">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>District</strong></td>\r\n			<td>:</td>\r\n			<td>[NP_DISTRICT]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Taluka</strong></td>\r\n			<td>:</td>\r\n			<td>[NP_TALUKA]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Village/Town</strong></td>\r\n			<td>:</td>\r\n			<td>[NP_VILLAGE]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Property Type</strong></td>\r\n			<td>:</td>\r\n			<td>[NP_TYPE]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Total Gut Survey Number(s)</strong></td>\r\n			<td>:</td>\r\n			<td>[NP_TOTAL_SURVEYS]</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan="3">[NP_SURVEY_NOS]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Total Number of Owners</strong></td>\r\n			<td>:</td>\r\n			<td>[NP_TOTAL_OWNERS]</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan="3">[NP_OWNERS_LIST]</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan="3">[NP_OTHER_DETAILS]</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n\r\n<div style="width: 50%;float: left;">\r\n<h4><u>Your Property</u></h4>\r\n\r\n<table border="1" bordercolor="#0033CC" cellpadding="3" cellspacing="0">\r\n	<tbody>\r\n		<tr>\r\n			<td><strong>District</strong></td>\r\n			<td>:</td>\r\n			<td>[PR_DISTRICT]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Taluka</strong></td>\r\n			<td>:</td>\r\n			<td>[PR_TALUKA]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Village/Town</strong></td>\r\n			<td>:</td>\r\n			<td>[PR_VILLAGE]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Property Type</strong></td>\r\n			<td>:</td>\r\n			<td>[PR_TYPE]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Total Gut Survey Number(s)</strong></td>\r\n			<td>:</td>\r\n			<td>[PR_TOTAL_SURVEYS]</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan="3">[PR_SURVEY_NOS]</td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong>Total Number of Owners</strong></td>\r\n			<td>:</td>\r\n			<td>[PR_TOTAL_OWNERS]</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan="3">[PR_OWNERS_LIST]</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan="3">[PR_OTHER_DETAILS]</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div align="center">&copy; <a href="http://www.trackproperty.in">www.trackproperty.in</a></div>\r\n</div>\r\n</div>\r\n', 1, 0, '2016-06-21 13:07:48', '2016-07-05 12:51:11'),
(5, 'Contact Email', 'Contact Message', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px solid #333;">\r\n<div style="background:#3c8dbc;padding:5px;border-bottom:1px solid #333;">\r\n<h3 style="color:#FFF;font-weight:bold;">Contact Message</h3>\r\n</div>\r\n\r\n<div style="width:100%;float:left;background:#ecf0f5;">\r\n<div style="width:98%;float:left;padding:10px;">\r\n<p>New contact message from <span style="color:#800000;">[NAME] , </span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div style="width:100%;color:#333333">\r\n<table align="center" border="0" cellpadding="5" cellspacing="1" height="138" width="500">\r\n	<tbody>\r\n		<tr>\r\n			<td width="97"><strong><span style="color:#800000;">Name</span></strong></td>\r\n			<td width="20"><span style="color:#800000;">:</span></td>\r\n			<td width="380"><span style="color:#800000;">[NAME]</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong><span style="color:#800000;">Email</span></strong></td>\r\n			<td><span style="color:#800000;">:</span></td>\r\n			<td><span style="color:#800000;">[EMAIL]</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong><span style="color:#800000;">Mobile No</span></strong></td>\r\n			<td><span style="color:#800000;">:</span></td>\r\n			<td><span style="color:#800000;">[MOBILE_NO]</span></td>\r\n		</tr>\r\n		<tr>\r\n			<td><strong><span style="color:#800000;">Message</span></strong></td>\r\n			<td>:</td>\r\n			<td><span style="color:#800000;">[MESSAGE]</span></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><span style="color:#800000;">&nbsp;: </span></p>\r\n\r\n<p><span style="color:#800000;">&nbsp;: </span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div align="center" style="padding:10px;">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div align="center">&copy; <a href="http://www.trackproperty.in">www.trackproperty.in</a></div>\r\n</div>\r\n</div>\r\n', 1, 0, '2016-06-29 12:17:48', '2016-07-04 16:03:50'),
(6, 'Operator Registration Mail', 'Operator Registration Successfull ', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px solid #333;">\r\n<div style="background:#3c8dbc;padding:5px;border-bottom:1px solid #333;">\r\n<h3 style="color:#FFF;font-weight:bold;">Registration Successfull</h3>\r\n</div>\r\n\r\n<div style="width:100%;float:left;background:#ecf0f5;">\r\n<div style="width:98%;float:left;padding:10px;"><strong>Dear <span style="color:#A52A2A;">[OPERATOR_NAME]</span>,</strong>\r\n\r\n<p>Your are registered as operator with www.trackproperty.in&nbsp; , below is user login detail.</p>\r\n\r\n<div style="width:100%;color:#333333">\r\n<p><span style="font-size:18px;"><strong>Account Detail</strong></span></p>\r\n\r\n<p><span style="color:#800000;">[EMAIL]</span></p>\r\n\r\n<p><span style="color:#800000;">[PASSWORD]</span></p>\r\n\r\n<div align="center" style="padding:10px;">[LOGIN_LINK]</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div align="center">&copy; <a href="http://www.trackproperty.in">www.trackproperty.in</a></div>\r\n</div>\r\n</div>\r\n', 1, 0, '2016-07-05 10:57:14', '2016-07-05 10:57:14');

-- --------------------------------------------------------

--
-- Table structure for table `instant_payment_notifications`
--

CREATE TABLE IF NOT EXISTS `instant_payment_notifications` (
  `id` char(36) NOT NULL,
  `notify_version` varchar(64) DEFAULT NULL COMMENT 'IPN Version Number',
  `verify_sign` varchar(127) DEFAULT NULL COMMENT 'Encrypted string used to verify the authenticityof the tansaction',
  `test_ipn` int(11) DEFAULT NULL,
  `address_city` varchar(40) DEFAULT NULL COMMENT 'City of customers address',
  `address_country` varchar(64) DEFAULT NULL COMMENT 'Country of customers address',
  `address_country_code` varchar(2) DEFAULT NULL COMMENT 'Two character ISO 3166 country code',
  `address_name` varchar(128) DEFAULT NULL COMMENT 'Name used with address (included when customer provides a Gift address)',
  `address_state` varchar(40) DEFAULT NULL COMMENT 'State of customer address',
  `address_status` varchar(20) DEFAULT NULL COMMENT 'confirmed/unconfirmed',
  `address_street` varchar(200) DEFAULT NULL COMMENT 'Customer''s street address',
  `address_zip` varchar(20) DEFAULT NULL COMMENT 'Zip code of customer''s address',
  `first_name` varchar(64) DEFAULT NULL COMMENT 'Customer''s first name',
  `last_name` varchar(64) DEFAULT NULL COMMENT 'Customer''s last name',
  `payer_business_name` varchar(127) DEFAULT NULL COMMENT 'Customer''s company name, if customer represents a business',
  `payer_email` varchar(127) DEFAULT NULL COMMENT 'Customer''s primary email address. Use this email to provide any credits',
  `payer_id` varchar(13) DEFAULT NULL COMMENT 'Unique customer ID.',
  `payer_status` varchar(20) DEFAULT NULL COMMENT 'verified/unverified',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT 'Customer''s telephone number.',
  `residence_country` varchar(2) DEFAULT NULL COMMENT 'Two-Character ISO 3166 country code',
  `business` varchar(127) DEFAULT NULL COMMENT 'Email address or account ID of the payment recipient (that is, the merchant). Equivalent to the values of receiver_email (If payment is sent to primary account) and business set in the Website Payment HTML.',
  `item_name` varchar(127) DEFAULT NULL COMMENT 'Item name as passed by you, the merchant. Or, if not passed by you, as entered by your customer. If this is a shopping cart transaction, Paypal will append the number of the item (e.g., item_name_1,item_name_2, and so forth).',
  `item_number` varchar(127) DEFAULT NULL COMMENT 'Pass-through variable for you to track purchases. It will get passed back to you at the completion of the payment. If omitted, no variable will be passed back to you.',
  `quantity` varchar(127) DEFAULT NULL COMMENT 'Quantity as entered by your customer or as passed by you, the merchant. If this is a shopping cart transaction, PayPal appends the number of the item (e.g., quantity1,quantity2).',
  `receiver_email` varchar(127) DEFAULT NULL COMMENT 'Primary email address of the payment recipient (that is, the merchant). If the payment is sent to a non-primary email address on your PayPal account, the receiver_email is still your primary email.',
  `receiver_id` varchar(13) DEFAULT NULL COMMENT 'Unique account ID of the payment recipient (i.e., the merchant). This is the same as the recipients referral ID.',
  `custom` varchar(255) DEFAULT NULL COMMENT 'Custom value as passed by you, the merchant. These are pass-through variables that are never presented to your customer.',
  `invoice` varchar(127) DEFAULT NULL COMMENT 'Pass through variable you can use to identify your invoice number for this purchase. If omitted, no variable is passed back.',
  `memo` varchar(255) DEFAULT NULL COMMENT 'Memo as entered by your customer in PayPal Website Payments note field.',
  `option_name1` varchar(64) DEFAULT NULL COMMENT 'Option name 1 as requested by you',
  `option_name2` varchar(64) DEFAULT NULL COMMENT 'Option 2 name as requested by you',
  `option_selection1` varchar(200) DEFAULT NULL COMMENT 'Option 1 choice as entered by your customer',
  `option_selection2` varchar(200) DEFAULT NULL COMMENT 'Option 2 choice as entered by your customer',
  `tax` decimal(10,2) DEFAULT NULL COMMENT 'Amount of tax charged on payment',
  `auth_id` varchar(19) DEFAULT NULL COMMENT 'Authorization identification number',
  `auth_exp` varchar(28) DEFAULT NULL COMMENT 'Authorization expiration date and time, in the following format: HH:MM:SS DD Mmm YY, YYYY PST',
  `auth_amount` int(11) DEFAULT NULL COMMENT 'Authorization amount',
  `auth_status` varchar(20) DEFAULT NULL COMMENT 'Status of authorization',
  `num_cart_items` int(11) DEFAULT NULL COMMENT 'If this is a PayPal shopping cart transaction, number of items in the cart',
  `parent_txn_id` varchar(19) DEFAULT NULL COMMENT 'In the case of a refund, reversal, or cancelled reversal, this variable contains the txn_id of the original transaction, while txn_id contains a new ID for the new transaction.',
  `payment_date` varchar(28) DEFAULT NULL COMMENT 'Time/date stamp generated by PayPal, in the following format: HH:MM:SS DD Mmm YY, YYYY PST',
  `payment_status` varchar(20) DEFAULT NULL COMMENT 'Payment status of the payment',
  `payment_type` varchar(10) DEFAULT NULL COMMENT 'echeck/instant',
  `pending_reason` varchar(20) DEFAULT NULL COMMENT 'This variable is only set if payment_status=pending',
  `reason_code` varchar(20) DEFAULT NULL COMMENT 'This variable is only set if payment_status=reversed',
  `remaining_settle` int(11) DEFAULT NULL COMMENT 'Remaining amount that can be captured with Authorization and Capture',
  `shipping_method` varchar(64) DEFAULT NULL COMMENT 'The name of a shipping method from the shipping calculations section of the merchants account profile. The buyer selected the named shipping method for this transaction',
  `shipping` decimal(10,2) DEFAULT NULL COMMENT 'Shipping charges associated with this transaction. Format unsigned, no currency symbol, two decimal places',
  `transaction_entity` varchar(20) DEFAULT NULL COMMENT 'Authorization and capture transaction entity',
  `txn_id` varchar(19) DEFAULT '' COMMENT 'A unique transaction ID generated by PayPal',
  `txn_type` varchar(20) DEFAULT NULL COMMENT 'cart/express_checkout/send-money/virtual-terminal/web-accept',
  `exchange_rate` decimal(10,2) DEFAULT NULL COMMENT 'Exchange rate used if a currency conversion occured',
  `mc_currency` varchar(3) DEFAULT NULL COMMENT 'Three character country code. For payment IPN notifications, this is the currency of the payment, for non-payment subscription IPN notifications, this is the currency of the subscription.',
  `mc_fee` decimal(10,2) DEFAULT NULL COMMENT 'Transaction fee associated with the payment, mc_gross minus mc_fee equals the amount deposited into the receiver_email account. Equivalent to payment_fee for USD payments. If this amount is negative, it signifies a refund or reversal, and either ofthose p',
  `mc_gross` decimal(10,2) DEFAULT NULL COMMENT 'Full amount of the customer''s payment',
  `mc_handling` decimal(10,2) DEFAULT NULL COMMENT 'Total handling charge associated with the transaction',
  `mc_shipping` decimal(10,2) DEFAULT NULL COMMENT 'Total shipping amount associated with the transaction',
  `payment_fee` decimal(10,2) DEFAULT NULL COMMENT 'USD transaction fee associated with the payment',
  `payment_gross` decimal(10,2) DEFAULT NULL COMMENT 'Full USD amount of the customers payment transaction, before payment_fee is subtracted',
  `settle_amount` decimal(10,2) DEFAULT NULL COMMENT 'Amount that is deposited into the account''s primary balance after a currency conversion',
  `settle_currency` varchar(3) DEFAULT NULL COMMENT 'Currency of settle amount. Three digit currency code',
  `auction_buyer_id` varchar(64) DEFAULT NULL COMMENT 'The customer''s auction ID.',
  `auction_closing_date` varchar(28) DEFAULT NULL COMMENT 'The auction''s close date. In the format: HH:MM:SS DD Mmm YY, YYYY PSD',
  `auction_multi_item` int(11) DEFAULT NULL COMMENT 'The number of items purchased in multi-item auction payments',
  `for_auction` varchar(10) DEFAULT NULL COMMENT 'This is an auction payment - payments made using Pay for eBay Items or Smart Logos - as well as send money/money request payments with the type eBay items or Auction Goods(non-eBay)',
  `subscr_date` varchar(28) DEFAULT NULL COMMENT 'Start date or cancellation date depending on whether txn_type is subcr_signup or subscr_cancel',
  `subscr_effective` varchar(28) DEFAULT NULL COMMENT 'Date when a subscription modification becomes effective',
  `period1` varchar(10) DEFAULT NULL COMMENT '(Optional) Trial subscription interval in days, weeks, months, years (example a 4 day interval is 4 D',
  `period2` varchar(10) DEFAULT NULL COMMENT '(Optional) Trial period',
  `period3` varchar(10) DEFAULT NULL COMMENT 'Regular subscription interval in days, weeks, months, years',
  `amount1` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for Trial period 1 for USD',
  `amount2` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for Trial period 2 for USD',
  `amount3` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for regular subscription  period 1 for USD',
  `mc_amount1` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for trial period 1 regardless of currency',
  `mc_amount2` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for trial period 2 regardless of currency',
  `mc_amount3` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for regular subscription period regardless of currency',
  `recurring` varchar(1) DEFAULT NULL COMMENT 'Indicates whether rate recurs (1 is yes, blank is no)',
  `reattempt` varchar(1) DEFAULT NULL COMMENT 'Indicates whether reattempts should occur on payment failure (1 is yes, blank is no)',
  `retry_at` varchar(28) DEFAULT NULL COMMENT 'Date PayPal will retry a failed subscription payment',
  `recur_times` int(11) DEFAULT NULL COMMENT 'The number of payment installations that will occur at the regular rate',
  `username` varchar(64) DEFAULT NULL COMMENT '(Optional) Username generated by PayPal and given to subscriber to access the subscription',
  `password` varchar(24) DEFAULT NULL COMMENT '(Optional) Password generated by PayPal and given to subscriber to access the subscription (Encrypted)',
  `subscr_id` varchar(19) DEFAULT NULL COMMENT 'ID generated by PayPal for the subscriber',
  `case_id` varchar(28) DEFAULT NULL COMMENT 'Case identification number',
  `case_type` varchar(28) DEFAULT NULL COMMENT 'complaint/chargeback',
  `case_creation_date` varchar(28) DEFAULT NULL COMMENT 'Date/Time the case was registered',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `country_id` int(10) NOT NULL,
  `deleted` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `country_id`, `deleted`) VALUES
(1, 'en', 'English', 0, 0),
(2, 'lu', 'Luthania', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `news_details` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `news_details`, `image`, `created`, `modified`) VALUES
(32, 'ghtjil ghtjilghtji', '<p>ghtjilghtjilghtjilghtjilghtjilghtjilghtjilghtjilghtjilght</p>\r\n', '14640840687.jpg', '2016-04-20 15:51:19', '2016-05-24 15:31:08'),
(33, 'fftyyyiiooooo', '<p>fftyyyiiooooofftyyyiiooooofftyyyiiooooo</p>\r\n', '14640840608.jpg', '2016-04-20 15:51:51', '2016-05-24 15:31:00'),
(35, 'adc', '<p>sdrfd</p>\r\n', '146400241814.jpg', '2016-04-20 17:40:05', '2016-05-23 16:50:18'),
(36, 'yjh', '<p>hkj</p>\r\n', '146408405012.jpg', '2016-04-30 11:24:14', '2016-05-24 15:30:50'),
(37, 'fgfg', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '146408404011.jpg', '2016-04-30 11:26:24', '2016-05-24 15:30:41'),
(38, 'hello', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '14640840338.jpg', '2016-04-30 11:28:33', '2016-05-24 15:30:33');

-- --------------------------------------------------------

--
-- Table structure for table `news_papers`
--

CREATE TABLE IF NOT EXISTS `news_papers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `news_papers`
--

INSERT INTO `news_papers` (`id`, `name`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Times of India', 1, 0, '2016-06-07 10:44:30', '2016-06-07 10:44:30'),
(2, 'Navshakti', 1, 0, '2016-06-07 10:44:38', '2016-06-07 10:44:38'),
(3, 'Krushiwal', 1, 0, '2016-06-07 10:44:47', '2016-06-07 10:44:47'),
(4, 'Raigadcha Aawaj', 1, 0, '2016-06-07 10:45:04', '2016-06-07 10:45:15'),
(5, 'Ramprahar', 1, 0, '2016-06-07 10:45:27', '2016-06-07 10:45:27'),
(6, 'Raigad Nagari', 1, 0, '2016-06-07 10:45:46', '2016-06-07 10:45:46'),
(7, 'Loksatta', 1, 0, '2016-06-07 10:45:52', '2016-06-07 10:45:52'),
(8, 'Navakal', 1, 0, '2016-06-07 10:46:00', '2016-06-07 10:46:00'),
(9, 'Sagar', 1, 0, '2016-06-07 10:46:05', '2016-06-07 10:46:05'),
(10, 'Prahar', 1, 0, '2016-06-07 10:46:18', '2016-06-07 10:46:18'),
(11, 'Maharashtra Times', 1, 0, '2016-06-07 10:46:27', '2016-06-21 10:39:04'),
(12, 'Pudhari', 1, 0, '2016-06-07 10:46:34', '2016-06-07 10:46:34'),
(13, 'Raigad Times', 1, 0, '2016-06-07 10:46:46', '2016-06-15 12:31:10'),
(14, 'Punya Nagari', 1, 0, '2016-06-07 10:46:55', '2016-06-07 10:46:55'),
(15, 'Samna', 1, 0, '2016-06-07 10:47:02', '2016-06-07 10:47:02'),
(16, 'Sakal', 1, 0, '2016-06-07 10:47:08', '2016-06-07 10:47:08'),
(17, 'Lokmat', 1, 0, '2016-06-07 10:47:15', '2016-06-07 10:47:15');

-- --------------------------------------------------------

--
-- Table structure for table `noticed_properties`
--

CREATE TABLE IF NOT EXISTS `noticed_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `notice_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `middle_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `district` int(11) NOT NULL,
  `taluka` int(11) DEFAULT NULL,
  `village` int(11) NOT NULL,
  `property_type` int(11) NOT NULL,
  `area_unit` int(11) DEFAULT NULL,
  `area_y` float DEFAULT NULL,
  `area_x` float DEFAULT NULL,
  `total_area` float DEFAULT NULL,
  `total_surveys` int(5) NOT NULL,
  `total_owners` int(5) NOT NULL,
  `shop_no` varchar(100) NOT NULL,
  `plot_no` varchar(20) NOT NULL,
  `flat_no` varchar(20) NOT NULL,
  `bungalow_no` varchar(50) NOT NULL,
  `bungalow_name` varchar(220) NOT NULL,
  `city_survey_no` varchar(150) NOT NULL,
  `society_name` varchar(180) NOT NULL,
  `package` int(11) NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `package_start` datetime DEFAULT NULL,
  `package_end` datetime DEFAULT NULL,
  `mail_sent` tinyint(1) NOT NULL DEFAULT '0',
  `sms_sent` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `registered_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `noticed_properties`
--

INSERT INTO `noticed_properties` (`id`, `customer_id`, `notice_id`, `name`, `middle_name`, `last_name`, `district`, `taluka`, `village`, `property_type`, `area_unit`, `area_y`, `area_x`, `total_area`, `total_surveys`, `total_owners`, `shop_no`, `plot_no`, `flat_no`, `bungalow_no`, `bungalow_name`, `city_survey_no`, `society_name`, `package`, `is_paid`, `package_start`, `package_end`, `mail_sent`, `sms_sent`, `is_active`, `is_deleted`, `created`, `modified`, `registered_by`) VALUES
(1, 0, 1, '', '', '', 5, 1, 7, 3, 5, 0, 0, 5000, 1, 1, '', '22', '', '', '', '22', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-15 16:54:31', '2016-07-06 11:57:11', 0),
(2, 0, 2, '', '', '', 5, 1, 2, 3, 5, 0, 0, 5000, 1, 1, '', '20', '', '', '', '30', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-18 12:32:11', '2016-07-11 13:51:50', 0),
(3, 0, 3, '', '', '', 5, 1, 2, 3, 5, 0, 0, 5000, 1, 1, '', '20', '', '', '', '30', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-18 12:33:41', '2016-07-11 12:30:37', 0),
(4, 0, 4, '', '', '', 5, 1, 4, 3, 5, 0, 0, 5000, 1, 1, '', '66', '', '', '', '6450', '', 0, 0, NULL, NULL, 1, 1, 1, 0, '2016-06-18 12:36:52', '2016-07-11 14:07:41', 0),
(5, 0, 5, '', '', '', 5, 1, 14, 4, 5, 0, 0, 5000, 2, 2, '', '120', '210', '', '', '120130', 'xyz society', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-20 16:19:47', '2016-06-20 16:19:47', 0),
(6, 0, 5, '', '', '', 10, 17, 17, 3, 5, 0, 0, 5000, 1, 1, '', '141', '', '', '', '14120', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-20 16:23:08', '2016-06-20 16:23:08', 0),
(7, 0, 6, '', '', '', 10, 17, 16, 1, 5, 0, 0, 5000, 2, 1, '', '', '', '', '', '', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-23 10:54:35', '2016-06-23 10:54:35', 0),
(8, 0, 7, '', '', '', 5, 1, 2, 1, 5, 0, 0, 5000, 1, 1, '', '', '', '', '', '', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-06-23 10:57:34', '2016-06-23 10:57:34', 0),
(9, 0, 8, '', '', '', 5, 1, 2, 1, 5, 0, 0, 5000, 2, 2, '', '', '', '', '', '', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-02 14:04:35', '2016-07-02 14:04:35', 0),
(10, 0, 9, '', '', '', 3, 30, 30, 3, 5, 0, 0, 5000, 1, 1, '', '12', '', '', '', '120', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:09:02', '2016-07-04 11:09:02', 1),
(11, 0, 10, '', '', '', 3, 30, 30, 3, 5, 0, 0, 5000, 1, 1, '', '12', '', '', '', '120', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:10:08', '2016-07-04 11:10:08', 1),
(12, 0, 11, '', '', '', 3, 30, 30, 3, 5, 0, 0, 5000, 1, 1, '', '12', '', '', '', '120', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:10:33', '2016-07-04 11:10:33', 1),
(13, 0, 12, '', '', '', 3, 30, 30, 3, 5, 0, 0, 5000, 1, 1, '', '12', '', '', '', '120', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:10:47', '2016-07-04 11:10:47', 1),
(14, 0, 13, '', '', '', 3, 30, 30, 3, 5, 0, 0, 5000, 1, 1, '', '12', '', '', '', '120', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:12:04', '2016-07-09 13:28:28', 1),
(15, 0, 14, '', '', '', 10, 17, 16, 4, 5, 0, 0, 5000, 1, 2, '', '123', '110', '', '', '1546', 'Royal Society', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:42:40', '2016-07-09 13:15:05', 2),
(16, 0, 15, '', '', '', 10, 17, 16, 3, 5, 0, 0, 5000, 1, 1, '', '11', '', '', '', '222', '', 0, 0, NULL, NULL, 0, 0, 1, 0, '2016-07-04 11:47:55', '2016-07-06 16:53:37', 2);

-- --------------------------------------------------------

--
-- Table structure for table `noticed_property_owners`
--

CREATE TABLE IF NOT EXISTS `noticed_property_owners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `noticed_property_owners`
--

INSERT INTO `noticed_property_owners` (`id`, `property_id`, `name`, `created`, `modified`) VALUES
(2, 1, 'Mr Arun', '2016-06-15 16:55:14', '2016-06-15 16:55:14'),
(3, 2, 'Mr.AAAAA', '2016-06-18 12:32:11', '2016-06-18 12:32:11'),
(4, 3, 'Mr.AAAAA', '2016-06-18 12:33:41', '2016-06-18 12:33:41'),
(8, 5, 'Mr .Abc', '2016-06-20 16:19:47', '2016-06-20 16:19:47'),
(9, 5, 'Mr. Xyz', '2016-06-20 16:19:47', '2016-06-20 16:19:47'),
(10, 6, 'Mr.kkkkk', '2016-06-20 16:23:08', '2016-06-20 16:23:08'),
(11, 7, 'Mr. Harsh', '2016-06-23 10:54:35', '2016-06-23 10:54:35'),
(12, 8, 'Mr. Kailash', '2016-06-23 10:57:35', '2016-06-23 10:57:35'),
(13, 9, 'aaaa', '2016-07-02 14:04:36', '2016-07-02 14:04:36'),
(14, 9, 'bbbb', '2016-07-02 14:04:36', '2016-07-02 14:04:36'),
(15, 10, 'aaa', '2016-07-04 11:09:03', '2016-07-04 11:09:03'),
(16, 11, 'aaa', '2016-07-04 11:10:08', '2016-07-04 11:10:08'),
(17, 12, 'aaa', '2016-07-04 11:10:33', '2016-07-04 11:10:33'),
(18, 13, 'aaa', '2016-07-04 11:10:47', '2016-07-04 11:10:47'),
(24, 4, 'Kailash', '2016-07-06 16:26:36', '2016-07-06 16:26:36'),
(27, 16, 'MMMM', '2016-07-06 16:53:38', '2016-07-06 16:53:38'),
(30, 15, 'xxxx', '2016-07-09 13:15:05', '2016-07-09 13:15:05'),
(31, 15, 'yyyyy', '2016-07-09 13:15:05', '2016-07-09 13:15:05'),
(33, 14, 'aaa', '2016-07-09 13:28:29', '2016-07-09 13:28:29');

-- --------------------------------------------------------

--
-- Table structure for table `noticed_survey_numbers`
--

CREATE TABLE IF NOT EXISTS `noticed_survey_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `gut_survey_no` varchar(100) NOT NULL,
  `hissa_part_no` varchar(100) NOT NULL,
  `survey_no` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `noticed_survey_numbers`
--

INSERT INTO `noticed_survey_numbers` (`id`, `property_id`, `gut_survey_no`, `hissa_part_no`, `survey_no`, `created`, `modified`) VALUES
(2, 1, '21', '22', '21/22', '2016-06-15 16:55:14', '2016-06-15 16:55:14'),
(3, 2, '50', '51', '50/51', '2016-06-18 12:32:11', '2016-06-18 12:32:11'),
(4, 3, '50', '51', '50/51', '2016-06-18 12:33:41', '2016-06-18 12:33:41'),
(8, 5, '101', '102', '101/102', '2016-06-20 16:19:47', '2016-06-20 16:19:47'),
(9, 5, '103', '104', '103/104', '2016-06-20 16:19:47', '2016-06-20 16:19:47'),
(10, 6, '140', '141', '140/141', '2016-06-20 16:23:08', '2016-06-20 16:23:08'),
(11, 7, '102', '103', '102/103', '2016-06-23 10:54:35', '2016-06-23 10:54:35'),
(12, 7, '104', '105', '104/105', '2016-06-23 10:54:35', '2016-06-23 10:54:35'),
(13, 8, '106', '107', '106/107', '2016-06-23 10:57:35', '2016-06-23 10:57:35'),
(14, 9, '1', '2', '1/2', '2016-07-02 14:04:35', '2016-07-02 14:04:35'),
(15, 9, '3', '4', '3/4', '2016-07-02 14:04:36', '2016-07-02 14:04:36'),
(16, 10, '1', '2', '1/2', '2016-07-04 11:09:02', '2016-07-04 11:09:02'),
(17, 11, '1', '2', '1/2', '2016-07-04 11:10:08', '2016-07-04 11:10:08'),
(18, 12, '1', '2', '1/2', '2016-07-04 11:10:33', '2016-07-04 11:10:33'),
(19, 13, '1', '2', '1/2', '2016-07-04 11:10:47', '2016-07-04 11:10:47'),
(24, 4, '12', '13', '12/13', '2016-07-06 16:26:36', '2016-07-06 16:26:36'),
(27, 16, '111', '112', '111/112', '2016-07-06 16:53:38', '2016-07-06 16:53:38'),
(29, 15, '12', '13', '12/13', '2016-07-09 13:15:05', '2016-07-09 13:15:05'),
(31, 14, '1', '2', '1/2', '2016-07-09 13:28:29', '2016-07-09 13:28:29');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE IF NOT EXISTS `notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advocate_id` int(11) NOT NULL,
  `notice_date` date DEFAULT NULL,
  `last_date` date DEFAULT NULL,
  `news_paper` int(11) NOT NULL,
  `page_no` varchar(20) NOT NULL,
  `notice_type` int(11) NOT NULL,
  `notice_period` varchar(100) NOT NULL,
  `notice_image` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `registered_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `advocate_id`, `notice_date`, `last_date`, `news_paper`, `page_no`, `notice_type`, `notice_period`, `notice_image`, `is_active`, `is_deleted`, `created`, `modified`, `registered_by`) VALUES
(1, 15, '2016-07-05', '2016-08-04', 1, '6', 3, '30', '146598987113.jpg', 1, 0, '2016-06-15 16:54:31', '2016-07-09 18:59:46', 1),
(2, 7, '2016-06-30', '2016-07-20', 2, '6', 1, '20', '146623333110.jpg', 1, 0, '2016-06-18 12:32:11', '2016-07-05 11:05:19', 1),
(3, 7, '2016-07-04', '2016-07-24', 2, '6', 1, '20', '14662334217.jpg', 1, 0, '2016-06-18 12:33:41', '2016-07-05 11:05:48', 1),
(4, 10, '2016-07-05', '2016-07-25', 3, '6', 3, '20', '146623361213.jpg', 1, 0, '2016-06-18 12:36:52', '2016-07-05 13:15:41', 1),
(5, 17, '2016-06-11', '2016-06-30', 11, '5', 7, '15', '14664197875.jpg', 1, 0, '2016-06-20 16:19:47', '2016-06-20 16:19:47', 2),
(6, 11, '2016-06-07', '2016-06-25', 17, '6', 3, '15', '146665947510.jpg', 1, 0, '2016-06-23 10:54:35', '2016-06-23 10:54:35', 2),
(7, 15, '2016-06-01', '2016-06-16', 17, '5', 2, '15', '146665965411.jpg', 1, 0, '2016-06-23 10:57:34', '2016-06-23 11:01:58', 3),
(8, 15, '2016-07-02', '2016-08-21', 1, '6', 1, '50', '146744847512.jpg', 1, 0, '2016-07-02 14:04:35', '2016-07-02 14:04:35', 1),
(9, 15, '2016-07-04', '2016-08-23', 1, '6', 1, '50', '146761074211.jpg', 1, 0, '2016-07-04 11:09:02', '2016-07-04 11:09:02', 1),
(10, 15, '2016-07-04', '2016-08-23', 1, '6', 1, '50', '14676108085.jpg', 1, 0, '2016-07-04 11:10:08', '2016-07-04 11:10:08', 1),
(11, 15, '2016-07-04', '2016-08-23', 1, '6', 1, '50', '146761083315.jpg', 1, 0, '2016-07-04 11:10:33', '2016-07-04 11:10:33', 1),
(12, 15, '2016-07-04', '2016-08-23', 1, '6', 1, '50', '146761084715.jpg', 1, 0, '2016-07-04 11:10:47', '2016-07-04 11:37:58', 1),
(13, 15, '2016-07-04', '2016-08-23', 1, '6', 1, '50', '146761092410.jpg', 1, 0, '2016-07-04 11:12:04', '2016-07-04 11:37:59', 1),
(14, 7, '2016-07-04', '2016-07-24', 1, '5', 3, '20', '146761276010.jpg', 1, 0, '2016-07-04 11:42:40', '2016-07-04 11:42:40', 2),
(15, 14, '2016-07-04', '2016-08-23', 1, '5', 3, '50', '146761307511.jpg', 1, 0, '2016-07-04 11:47:55', '2016-07-04 11:47:55', 2);

-- --------------------------------------------------------

--
-- Table structure for table `notice_types`
--

CREATE TABLE IF NOT EXISTS `notice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `notice_types`
--

INSERT INTO `notice_types` (`id`, `name`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Title Search Notice', 1, 0, '2016-06-04 17:15:49', '2016-06-04 17:15:49'),
(2, 'Title Verification Notice', 1, 0, '2016-06-04 17:16:07', '2016-06-04 17:16:07'),
(3, 'Jahir Notice', 1, 0, '2016-06-04 17:16:19', '2016-06-04 17:16:19'),
(4, 'Court Notice', 1, 0, '2016-06-04 17:16:27', '2016-06-07 10:49:28'),
(5, 'SDO Notice', 1, 0, '2016-06-04 17:16:33', '2016-06-04 17:16:33'),
(6, 'Tahsildar Notice', 1, 0, '2016-06-04 17:16:44', '2016-06-04 17:16:44'),
(7, 'Bank Notice', 1, 0, '2016-06-04 17:16:52', '2016-06-04 17:16:52'),
(8, 'Acquisition Notice', 1, 0, '2016-06-04 17:17:03', '2016-06-04 17:17:03'),
(9, 'MIDC Acquisition Notice', 1, 0, '2016-06-04 17:17:14', '2016-06-04 17:17:14'),
(10, 'Objection Notice', 1, 0, '2016-06-04 17:17:23', '2016-06-04 17:17:23'),
(11, 'Attention Notice', 1, 0, '2016-06-04 17:17:31', '2016-06-04 17:17:31');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `validity` int(11) NOT NULL,
  `cost` float(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `description`, `validity`, `cost`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Silver', '<ul>\r\n	<li>dsd sa dsd</li>\r\n	<li>dddasdasdasdasd</li>\r\n	<li>dsd sa dsd</li>\r\n	<li>dddasdasdasdasd</li>\r\n	<li>dsd sa dsd</li>\r\n	<li>dddasdasdasdasd</li>\r\n	<li>dsd sa dsd</li>\r\n	<li>dddasdasdasdasd</li>\r\n	<li>dsd sa dsd</li>\r\n	<li>dddasdasdasdasd</li>\r\n</ul>\r\n', 60, 1500.00, 1, 0, '2016-06-06 14:55:23', '2016-06-06 14:58:32');

-- --------------------------------------------------------

--
-- Table structure for table `paypal_items`
--

CREATE TABLE IF NOT EXISTS `paypal_items` (
  `id` varchar(36) NOT NULL,
  `instant_payment_notification_id` varchar(36) NOT NULL,
  `item_name` varchar(127) DEFAULT NULL,
  `item_number` varchar(127) DEFAULT NULL,
  `quantity` varchar(127) DEFAULT NULL,
  `mc_gross` float(10,2) DEFAULT NULL,
  `mc_shipping` float(10,2) DEFAULT NULL,
  `mc_handling` float(10,2) DEFAULT NULL,
  `tax` float(10,2) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `professions`
--

CREATE TABLE IF NOT EXISTS `professions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `professions`
--

INSERT INTO `professions` (`id`, `name`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Engineer', 1, 0, '2016-06-06 11:12:06', '2016-06-06 11:12:56'),
(2, 'Doctor', 1, 0, '2016-06-06 11:14:22', '2016-06-06 11:14:28'),
(3, 'Chartered Accountant', 1, 0, '2016-06-06 11:15:03', '2016-06-06 11:15:13'),
(4, 'asa', 1, 0, '2016-06-06 11:31:06', '2016-06-06 11:31:06'),
(5, 'asdas', 1, 0, '2016-06-06 11:31:09', '2016-06-06 11:31:09'),
(6, 'asdasdsadasd', 1, 0, '2016-06-06 11:31:13', '2016-06-06 11:31:13'),
(7, 'gfgf', 1, 0, '2016-06-06 11:31:16', '2016-06-06 11:31:16'),
(8, 'nbnbnbn', 1, 0, '2016-06-06 11:31:20', '2016-06-06 11:31:20'),
(9, 'ewwewe', 1, 0, '2016-06-06 11:31:23', '2016-06-06 11:31:23'),
(10, 'jkjkjkjk', 1, 0, '2016-06-06 11:31:27', '2016-06-06 11:31:27'),
(11, 'uyuyuy', 1, 0, '2016-06-06 11:31:30', '2016-06-06 11:31:30'),
(12, 'dgetesdertr', 0, 1, '2016-06-06 11:31:36', '2016-06-06 12:30:16'),
(13, 'kjhkfggfewwecvv', 1, 0, '2016-06-06 11:31:41', '2016-06-06 11:31:41'),
(15, 'dgetesdertr', 1, 0, '2016-06-06 12:30:18', '2016-06-06 12:30:18');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE IF NOT EXISTS `properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `middle_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `district` int(11) NOT NULL,
  `taluka` int(11) NOT NULL,
  `village` int(11) NOT NULL,
  `property_type` int(11) NOT NULL,
  `area_unit` int(11) NOT NULL,
  `area_x` float DEFAULT NULL,
  `area_y` float DEFAULT NULL,
  `total_area` float DEFAULT NULL,
  `total_surveys` int(5) NOT NULL,
  `total_owners` int(5) NOT NULL,
  `shop_no` varchar(100) NOT NULL,
  `plot_no` varchar(20) NOT NULL,
  `flat_no` varchar(20) NOT NULL,
  `bungalow_no` varchar(50) NOT NULL,
  `bungalow_name` varchar(220) NOT NULL,
  `city_survey_no` varchar(150) NOT NULL,
  `society_name` varchar(180) NOT NULL,
  `package` int(11) NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `package_start` datetime DEFAULT NULL,
  `package_end` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `registered_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `customer_id`, `name`, `middle_name`, `last_name`, `district`, `taluka`, `village`, `property_type`, `area_unit`, `area_x`, `area_y`, `total_area`, `total_surveys`, `total_owners`, `shop_no`, `plot_no`, `flat_no`, `bungalow_no`, `bungalow_name`, `city_survey_no`, `society_name`, `package`, `is_paid`, `package_start`, `package_end`, `is_active`, `is_deleted`, `created`, `modified`, `registered_by`) VALUES
(1, 4, '', '', '', 10, 17, 16, 3, 5, 0, 0, 5000, 1, 1, '', '1', '', '', '', '101', '', 0, 0, NULL, NULL, 1, 0, '2016-06-15 15:55:06', '2016-07-09 13:20:44', 0),
(2, 19, '', '', '', 10, 17, 21, 4, 5, 0, 0, 5000, 1, 1, '', '500', '120', '', '', '120', 'Govindrao Society', 0, 0, NULL, NULL, 1, 0, '2016-06-15 15:57:41', '2016-06-15 15:57:41', 0),
(3, 19, '', '', '', 10, 17, 20, 3, 5, 0, 0, 5000, 2, 2, '', '60', '', '', '', '60', '', 0, 0, NULL, NULL, 1, 0, '2016-06-15 15:58:43', '2016-06-15 15:58:43', 0),
(4, 4, '', '', '', 10, 17, 19, 3, 5, 0, 0, 5000, 1, 1, '', '81', '', '', '', '81', '', 0, 0, NULL, NULL, 1, 0, '2016-06-15 15:59:29', '2016-06-15 16:51:45', 0),
(5, 20, '', '', '', 5, 1, 7, 3, 5, 0, 0, 5000, 1, 1, '', '23', '', '', '', '22', '', 0, 0, NULL, NULL, 1, 0, '2016-06-15 16:45:49', '2016-06-21 16:23:12', 0),
(6, 4, '', '', '', 10, 17, 16, 3, 5, 0, 0, 5000, 2, 2, '', '12', '', '', '', '1245', '', 0, 0, NULL, NULL, 1, 0, '2016-06-17 16:00:11', '2016-06-17 16:00:11', 0),
(7, 4, '', '', '', 10, 17, 27, 3, 5, 0, 0, 5000, 2, 2, '', '678', '', '', '', '23', '', 0, 0, NULL, NULL, 1, 0, '2016-06-17 16:02:28', '2016-06-21 10:30:18', 0),
(8, 4, '', '', '', 10, 17, 22, 3, 5, 0, 0, 5000, 1, 1, '', '9', '', '', '', '910', '', 0, 1, NULL, NULL, 1, 0, '2016-06-17 16:03:40', '2016-07-06 17:03:05', 0),
(9, 4, '', '', '', 5, 1, 2, 3, 5, 0, 0, 5000, 2, 1, '', '21', '121211', '', '', '210', '11', 0, 1, NULL, NULL, 1, 0, '2016-06-17 16:14:15', '2016-07-06 16:26:51', 0),
(10, 4, '', '', '', 5, 1, 4, 3, 5, 0, 0, 5000, 2, 1, '', '66', '', '', '', '6450', '', 0, 1, NULL, NULL, 1, 0, '2016-06-17 16:19:29', '2016-06-30 11:03:01', 0),
(11, 4, '', '', '', 5, 1, 2, 3, 5, 0, 0, 5000, 1, 1, '', '20', '', '', '', '30', '', 0, 0, NULL, NULL, 1, 0, '2016-06-17 16:20:24', '2016-07-04 11:34:58', 0),
(12, 4, '', '', '', 5, 1, 2, 1, 5, 0, 0, 5000, 2, 2, '', '22', '', '', '', '33', '', 0, 0, NULL, NULL, 1, 0, '2016-06-30 10:46:34', '2016-07-06 17:04:02', 0),
(13, 55, '', '', '', 5, 1, 1, 1, 5, 0, 0, 5000, 1, 1, '', '', '', '', '', '', '', 0, 0, NULL, NULL, 1, 0, '2016-07-04 11:36:54', '2016-07-04 11:36:54', 2),
(14, 4, '', '', '', 5, 1, 2, 2, 8, 0, 0, 15, 1, 1, '', '', '', '', '', '', '', 0, 0, NULL, NULL, 1, 0, '2016-07-09 12:56:04', '2016-07-09 14:24:57', 1);

-- --------------------------------------------------------

--
-- Table structure for table `property_owners`
--

CREATE TABLE IF NOT EXISTS `property_owners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `property_owners`
--

INSERT INTO `property_owners` (`id`, `property_id`, `name`, `created`, `modified`) VALUES
(24, 2, 'Mr Arun', '2016-06-15 15:57:41', '2016-06-15 15:57:41'),
(25, 3, 'Arun Kumar', '2016-06-15 15:58:43', '2016-06-15 15:58:43'),
(26, 3, 'Anil Kumar', '2016-06-15 15:58:43', '2016-06-15 15:58:43'),
(27, 4, 'Mr Masood', '2016-06-15 15:59:29', '2016-06-15 15:59:29'),
(30, 6, 'Mr Abcc', '2016-06-17 16:00:11', '2016-06-17 16:00:11'),
(31, 6, 'Mr Deff', '2016-06-17 16:00:11', '2016-06-17 16:00:11'),
(32, 7, 'Mr.aaa', '2016-06-17 16:02:28', '2016-06-17 16:02:28'),
(33, 7, 'Mr.bbb', '2016-06-17 16:02:28', '2016-06-17 16:02:28'),
(41, 11, 'asddds fdsdf sd', '2016-06-18 12:32:33', '2016-06-18 12:32:33'),
(42, 10, 'Kailash', '2016-06-18 15:35:09', '2016-06-18 15:35:09'),
(46, 5, 'Mr Arun', '2016-06-21 16:23:12', '2016-06-21 16:23:12'),
(55, 13, '123', '2016-07-04 11:36:54', '2016-07-04 11:36:54'),
(59, 9, 'Mr. Dilip', '2016-07-06 16:26:51', '2016-07-06 16:26:51'),
(61, 8, 'Mr .xyz', '2016-07-06 17:03:05', '2016-07-06 17:03:05'),
(64, 12, 'aaa', '2016-07-06 17:04:02', '2016-07-06 17:04:02'),
(65, 12, 'bbb', '2016-07-06 17:04:02', '2016-07-06 17:04:02'),
(67, 1, 'a1', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(68, 1, 'a2', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(69, 1, 'a3', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(70, 1, 'Owner name1', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(71, 1, 'Owner name2', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(72, 1, 'Mr. Kailash Gupta', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(74, 14, 'asassaasassa', '2016-07-09 14:24:57', '2016-07-09 14:24:57');

-- --------------------------------------------------------

--
-- Table structure for table `property_types`
--

CREATE TABLE IF NOT EXISTS `property_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `property_types`
--

INSERT INTO `property_types` (`id`, `name`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Agriculture Land', 1, 0, '2016-06-07 00:00:00', '2016-06-07 00:00:00'),
(2, 'Non Agriculture Land', 1, 0, '2016-06-07 00:00:00', '2016-06-07 00:00:00'),
(3, 'Plot', 1, 0, '2016-06-03 00:00:00', '2016-06-03 00:00:00'),
(4, 'Flat', 1, 0, '2016-06-07 00:00:00', '2016-06-07 00:00:00'),
(5, 'Bungalow', 1, 0, '2016-06-03 00:00:00', '2016-06-03 00:00:00'),
(6, 'Row House / Row Bungalow', 1, 0, NULL, NULL),
(7, 'Shop', 1, 0, '2016-06-03 00:00:00', '2016-06-03 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'role id -primary key',
  `name` varchar(100) NOT NULL COMMENT 'Different type of users category',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '1=>active/0=>de-active',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '1=>deleted/0=>not deleted',
  `created` timestamp NULL DEFAULT NULL COMMENT 'created time',
  `modified` timestamp NULL DEFAULT NULL COMMENT 'modified time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_id_UNIQUE` (`id`),
  UNIQUE KEY `role_UNIQUE` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Administrator', 1, 0, '2014-11-13 16:08:50', '2014-11-14 17:47:45'),
(2, 'Operator', 1, 0, '2015-06-05 07:02:20', '2015-06-05 07:02:20'),
(3, 'Dealer', 1, 0, '2015-06-05 07:02:20', '2015-06-05 07:02:20'),
(4, 'Agent', 1, 0, '2016-04-22 18:30:00', '2015-06-05 07:02:20'),
(5, 'Advocate', 1, 0, '2016-04-22 18:30:00', '2015-06-05 07:02:20'),
(6, 'Customer', 1, 0, '2016-04-22 18:30:00', '2016-04-22 18:30:00'),
(7, 'Co-Administrator', 1, 0, '2014-11-13 16:08:50', '2014-11-14 17:47:45');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE IF NOT EXISTS `role_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL COMMENT 'foreign key from role table',
  `permission_id` int(11) NOT NULL COMMENT 'foreign key from permission table',
  `is_permitted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=> Not Permitted/ 1=> Permitted',
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0=> Not active/ 1=> active',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=> Not deleted/ 1=> deleted',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`id`, `role_id`, `permission_id`, `is_permitted`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 1, 1, 1, 1, 0, '2014-11-29 06:01:10', '2014-11-29 06:01:52'),
(2, 1, 2, 1, 1, 0, '2014-11-29 06:01:10', '2014-11-29 06:01:53'),
(3, 1, 3, 1, 1, 0, '2014-11-29 06:01:10', '2014-11-29 06:01:54'),
(4, 1, 4, 1, 1, 0, '2014-11-29 06:01:10', '2014-11-29 06:01:55'),
(5, 2, 1, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 06:26:05'),
(6, 2, 2, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 06:26:06'),
(7, 2, 3, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 07:35:30'),
(8, 2, 4, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 07:37:31'),
(9, 6, 1, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 06:26:05'),
(10, 6, 2, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 06:26:06'),
(11, 6, 3, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 07:35:30'),
(12, 6, 4, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 07:37:31'),
(13, 7, 1, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 06:26:05'),
(14, 7, 2, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 06:26:06'),
(15, 7, 3, 1, 1, 0, '2014-11-29 06:25:52', '2014-11-29 07:35:30');

-- --------------------------------------------------------

--
-- Table structure for table `sending_emails`
--

CREATE TABLE IF NOT EXISTS `sending_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_email` varchar(150) NOT NULL,
  `reciever_email` varchar(150) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `content` varchar(100) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `attempts` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sending_emails`
--

INSERT INTO `sending_emails` (`id`, `sender_email`, `reciever_email`, `user_id`, `subject`, `content`, `status`, `attempts`, `created`, `modified`) VALUES
(1, 'support@tractomandi.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-06-23 13:21:36', '2016-06-23 13:21:36'),
(2, 'support@tractomandi.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-06-23 13:21:37', '2016-06-23 13:21:37'),
(3, 'support@tractomandi.com', 'mohammadmasood01@gmail.com', 20, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-06-23 13:21:38', '2016-06-23 13:21:38'),
(4, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-05 11:23:15', '2016-07-05 11:23:15'),
(5, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 12:29:57', '2016-07-11 12:29:57'),
(6, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 12:30:03', '2016-07-11 12:30:03'),
(7, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 12:30:37', '2016-07-11 12:30:37'),
(8, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:42:08', '2016-07-11 13:42:08'),
(9, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:42:55', '2016-07-11 13:42:55'),
(10, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:47:13', '2016-07-11 13:47:13'),
(11, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:48:50', '2016-07-11 13:48:50'),
(12, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:49:35', '2016-07-11 13:49:35'),
(13, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:51:09', '2016-07-11 13:51:09'),
(14, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 13:51:50', '2016-07-11 13:51:50'),
(15, 'trackproperty@adsoftech.com', 'mohammadmasood01@gmail.com', 4, 'Property Notice Alert', '<div style="width:800px;float:left;">\r\n<div style="width:100%;float:left;margin:auto;border:1px soli', 1, 0, '2016-07-11 14:07:33', '2016-07-11 14:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `site_contents`
--

CREATE TABLE IF NOT EXISTS `site_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'content name  like About Us etc..',
  `slug` varchar(255) NOT NULL COMMENT 'about_us/faq etc.',
  `content` text NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0 = inactive, 1 = active',
  `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 = not deleted, 1 = deleted',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `site_contents`
--

INSERT INTO `site_contents` (`id`, `name`, `slug`, `content`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'About Us', 'about_us', '<section class="red-holder">\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-sm-10">\r\n<h1 class="hd1">About</h1>\r\n\r\n<p class="hd-paira">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>\r\n</div>\r\n\r\n<div class="col-sm-2 image-blog"><img alt="" class="img-responsive" src="images/about-img.png" /></div>\r\n</div>\r\n</div>\r\n</section>\r\n\r\n<section class="about-holder">\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-sm-12">\r\n<ul class="breadcrumb">\r\n	<li>&nbsp;</li>\r\n	<li>About</li>\r\n</ul>\r\n\r\n<h2 class="hd2">Introduction</h2>\r\n</div>\r\n</div>\r\n\r\n<div class="row">\r\n<div class="col-sm-6">\r\n<div class="intro-blog">\r\n<div class="intro-hd">\r\n<figure><span>WHO WE ARE</span></figure>\r\n</div>\r\n\r\n<div class="intro-infobox">\r\n<p>&quot;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</p>\r\n\r\n<div class="text-center"><a class="btn btn-darkgray" href="#">Read more </a></div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="col-sm-6">\r\n<div class="intro-blog">\r\n<div class="intro-hd">\r\n<figure><span>WHAT WE DO </span></figure>\r\n</div>\r\n\r\n<div class="intro-infobox">\r\n<p>&quot;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</p>\r\n\r\n<div class="text-center"><a class="btn btn-darkgray" href="#">Read more </a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n\r\n<section class="team-holder">\r\n<div class="team-bg">\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-sm-12">\r\n<div class="team-info">\r\n<h3>TEAM</h3>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-sm-4">\r\n<div class="team-users">\r\n<div class="team-usersimgbox">\r\n<figure><img alt="" class="img-responsive" src="images/tean-personx352x244.jpg" /></figure>\r\n</div>\r\n\r\n<div class="team-userinfo">\r\n<h4>CHAD SPENCER</h4>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed....</p>\r\n\r\n<div class="users-socialbox">\r\n<ul>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="col-sm-4">\r\n<div class="team-users">\r\n<div class="team-usersimgbox">\r\n<figure><img alt="" class="img-responsive" src="images/tean-psbx352x244.jpg" /></figure>\r\n</div>\r\n\r\n<div class="team-userinfo">\r\n<h4>CHAD SPENCER</h4>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed....</p>\r\n\r\n<div class="users-socialbox">\r\n<ul>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<div class="col-sm-4">\r\n<div class="team-users">\r\n<div class="team-usersimgbox">\r\n<figure><img alt="" class="img-responsive" src="images/tean-personx352x244.jpg" /></figure>\r\n</div>\r\n\r\n<div class="team-userinfo">\r\n<h4>CHAD SPENCER</h4>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed....</p>\r\n\r\n<div class="users-socialbox">\r\n<ul>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n', 1, 0, '0000-00-00 00:00:00', '2016-05-23 14:37:58'),
(21, 'Home', 'homecontent', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting</p>\r\n', 1, 0, '2016-03-04 12:45:43', '2016-05-23 14:37:47'),
(22, 'fddddddddddddd', '', '', 1, 0, '2016-05-23 15:15:10', '2016-05-23 15:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT 'site setting key',
  `value` varchar(255) NOT NULL COMMENT 'site setting value',
  `is_editable` tinyint(1) DEFAULT '0' COMMENT '0=>field is not editable by admin / 1=> editable ',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '0=>inactive/1=>active',
  `is_deleted` tinyint(1) DEFAULT '0' COMMENT '0=>not deleted/1=>deleted',
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='stores the different setting pertaing to the website' AUTO_INCREMENT=17 ;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `value`, `is_editable`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'site_name', 'Track Property', 1, 1, 0, '2016-04-10 14:19:46', NULL),
(2, 'site_email', 'info@trackproperty.in', 1, 1, 0, '2016-05-31 09:28:40', NULL),
(3, 'SMTP_HOST', 'mail.trackproperty.in', 0, 1, 0, '2016-05-31 09:27:26', NULL),
(4, 'SMTP_PORT', '25', 0, 1, 0, NULL, NULL),
(5, 'SMTP_USERNAME', 'info@trackproperty.in', 0, 1, 0, '2016-05-31 09:27:57', NULL),
(6, 'SMTP_PASSWORD', 'info@tpr!@#123', 0, 1, 0, '2016-05-31 09:28:08', NULL),
(7, 'API_USER_NAME', '', 1, 1, 0, '2016-04-10 14:22:57', NULL),
(8, 'API_PASSWORD', '', 1, 1, 0, NULL, NULL),
(9, 'API_SIGNATURE', '', 1, 1, 0, NULL, NULL),
(10, 'default_paypal_environment', 'sandbox', 1, 1, 0, NULL, NULL),
(11, 'facebook_appid', '', 1, 1, 0, NULL, NULL),
(12, 'twitter_consumer_key', '', 1, 1, 0, NULL, NULL),
(13, 'twitter_consumer_secret', '', 1, 1, 0, NULL, NULL),
(14, 'twitter_access_token', '', 1, 1, 0, NULL, NULL),
(15, 'twitter_access_token_secret', '', 1, 1, 0, NULL, NULL),
(16, 'SITE_UNDER_MAINTENANCE', '2', 1, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sms_sents`
--

CREATE TABLE IF NOT EXISTS `sms_sents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` varchar(150) NOT NULL,
  `sent_by` int(11) NOT NULL,
  `mobile_no` varchar(150) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(250) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `sms_sents`
--

INSERT INTO `sms_sents` (`id`, `sender_id`, `sent_by`, `mobile_no`, `user_id`, `message`, `status`, `created`, `modified`) VALUES
(1, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 09 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:09:25', '2016-06-25 12:09:25'),
(2, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 11 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:09:25', '2016-06-25 12:09:25'),
(3, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 10 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:09:25', '2016-06-25 12:09:25'),
(4, 'TrackP', 2, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 09 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:17:15', '2016-06-25 12:17:15'),
(5, 'TrackP', 2, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 11 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:17:16', '2016-06-25 12:17:16'),
(6, 'TrackP', 2, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 10 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:17:16', '2016-06-25 12:17:16'),
(7, 'TrackP', 2, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 09 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:17:46', '2016-06-25 12:17:46'),
(8, 'TrackP', 2, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 11 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:17:46', '2016-06-25 12:17:46'),
(9, 'TrackP', 2, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 10 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 12:17:46', '2016-06-25 12:17:46'),
(10, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 10 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-06-25 13:38:30', '2016-06-25 13:38:30'),
(11, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-05 11:14:24', '2016-07-05 11:14:24'),
(12, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-05 14:58:03', '2016-07-05 14:58:03'),
(13, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-05 14:59:35', '2016-07-05 14:59:35'),
(14, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-05 15:05:43', '2016-07-05 15:05:43'),
(15, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-05 15:05:47', '2016-07-05 15:05:47'),
(16, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:02:53', '2016-07-06 11:02:53'),
(17, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:02:54', '2016-07-06 11:02:54'),
(18, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:07:21', '2016-07-06 11:07:21'),
(19, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:07:21', '2016-07-06 11:07:21'),
(20, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:07:21', '2016-07-06 11:07:21'),
(21, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:08:10', '2016-07-06 11:08:10'),
(22, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:10:03', '2016-07-06 11:10:03'),
(23, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:10:03', '2016-07-06 11:10:03'),
(24, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:10:03', '2016-07-06 11:10:03'),
(25, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:13:52', '2016-07-06 11:13:52'),
(26, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:15:22', '2016-07-06 11:15:22'),
(27, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:15:22', '2016-07-06 11:15:22'),
(28, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:15:22', '2016-07-06 11:15:22'),
(29, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:16:33', '2016-07-06 11:16:33'),
(30, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:16:33', '2016-07-06 11:16:33'),
(31, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:16:33', '2016-07-06 11:16:33'),
(32, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:20:47', '2016-07-06 11:20:47'),
(33, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:20:47', '2016-07-06 11:20:47'),
(34, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:20:47', '2016-07-06 11:20:47'),
(35, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:30:34', '2016-07-06 11:30:34'),
(36, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:30:34', '2016-07-06 11:30:34'),
(37, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:30:34', '2016-07-06 11:30:34'),
(38, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:32:39', '2016-07-06 11:32:39'),
(39, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:32:40', '2016-07-06 11:32:40'),
(40, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:32:40', '2016-07-06 11:32:40'),
(41, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:33:34', '2016-07-06 11:33:34'),
(42, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:33:34', '2016-07-06 11:33:34'),
(43, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:33:34', '2016-07-06 11:33:34'),
(44, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:34:58', '2016-07-06 11:34:58'),
(45, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:34:58', '2016-07-06 11:34:58'),
(46, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:34:58', '2016-07-06 11:34:58'),
(47, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:35:42', '2016-07-06 11:35:42'),
(48, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:35:42', '2016-07-06 11:35:42'),
(49, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:35:42', '2016-07-06 11:35:42'),
(50, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:36:21', '2016-07-06 11:36:21'),
(51, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:36:21', '2016-07-06 11:36:21'),
(52, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:36:21', '2016-07-06 11:36:21'),
(53, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:39:25', '2016-07-06 11:39:25'),
(54, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:39:25', '2016-07-06 11:39:25'),
(55, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:39:25', '2016-07-06 11:39:25'),
(56, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:39:52', '2016-07-06 11:39:52'),
(57, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:41:19', '2016-07-06 11:41:19'),
(58, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:41:19', '2016-07-06 11:41:19'),
(59, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:41:19', '2016-07-06 11:41:19'),
(60, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:42:49', '2016-07-06 11:42:49'),
(61, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:42:49', '2016-07-06 11:42:49'),
(62, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:42:49', '2016-07-06 11:42:49'),
(63, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:43:23', '2016-07-06 11:43:23'),
(64, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:43:37', '2016-07-06 11:43:37'),
(65, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:43:38', '2016-07-06 11:43:38'),
(66, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:43:38', '2016-07-06 11:43:38'),
(67, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:44:52', '2016-07-06 11:44:52'),
(68, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:44:53', '2016-07-06 11:44:53'),
(69, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:44:53', '2016-07-06 11:44:53'),
(70, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:46:02', '2016-07-06 11:46:02'),
(71, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:46:02', '2016-07-06 11:46:02'),
(72, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:46:03', '2016-07-06 11:46:03'),
(73, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:46:52', '2016-07-06 11:46:52'),
(74, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:46:53', '2016-07-06 11:46:53'),
(75, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:46:53', '2016-07-06 11:46:53'),
(76, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:47:49', '2016-07-06 11:47:49'),
(77, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:47:49', '2016-07-06 11:47:49'),
(78, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:47:50', '2016-07-06 11:47:50'),
(79, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:49:23', '2016-07-06 11:49:23'),
(80, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:49:23', '2016-07-06 11:49:23'),
(81, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:49:23', '2016-07-06 11:49:23'),
(82, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:50:15', '2016-07-06 11:50:15'),
(83, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:50:15', '2016-07-06 11:50:15'),
(84, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:50:15', '2016-07-06 11:50:15'),
(85, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:52:52', '2016-07-06 11:52:52'),
(86, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:52:52', '2016-07-06 11:52:52'),
(87, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:52:52', '2016-07-06 11:52:52'),
(88, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:53:56', '2016-07-06 11:53:56'),
(89, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:53:56', '2016-07-06 11:53:56'),
(90, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:53:56', '2016-07-06 11:53:56'),
(91, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:54:21', '2016-07-06 11:54:21'),
(92, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:55:11', '2016-07-06 11:55:11'),
(93, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:55:11', '2016-07-06 11:55:11'),
(94, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:55:12', '2016-07-06 11:55:12'),
(95, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:55:20', '2016-07-06 11:55:20'),
(96, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:57:11', '2016-07-06 11:57:11'),
(97, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 30 Jun 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:57:11', '2016-07-06 11:57:11'),
(98, 'TrackP', 1, '9214587562', 20, 'Dear Manish ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Times of India news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:57:11', '2016-07-06 11:57:11'),
(99, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Title Search Notice'' on page 6 of Navshakti news paper dated 04 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-06 11:57:17', '2016-07-06 11:57:17'),
(100, 'TrackP', 1, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-11 13:56:50', '2016-07-11 13:56:50'),
(101, 'TrackP', 2, '8055736857', 4, 'Dear Mohammad ,You have a property notice , titled : ''Jahir Notice'' on page 6 of Krushiwal news paper dated 05 Jul 2016. visit : http://www.trackproperty.in', 1, '2016-07-11 14:07:41', '2016-07-11 14:07:41');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `country_id`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Andaman and Nicobar Island', 1, 1, 0, NULL, NULL),
(2, 'Andhra Pradesh', 1, 1, 0, NULL, NULL),
(3, 'Arunachal Pradesh', 1, 1, 0, NULL, NULL),
(4, 'Assam', 1, 1, 0, NULL, NULL),
(5, 'Bihar', 1, 1, 0, NULL, NULL),
(6, 'Chhattisgarh', 1, 1, 0, NULL, NULL),
(7, 'Dadra and Nagar Haveli', 1, 1, 0, NULL, NULL),
(8, 'Daman and Diu', 1, 1, 0, NULL, NULL),
(9, 'Delhi', 1, 1, 0, NULL, NULL),
(10, 'Goa', 1, 1, 0, NULL, NULL),
(11, 'Gujarat', 1, 1, 0, NULL, NULL),
(12, 'Haryana', 1, 1, 0, NULL, NULL),
(13, 'Himachal Pradesh', 1, 1, 0, NULL, NULL),
(14, 'Jammu and Kashmir', 1, 1, 0, NULL, NULL),
(15, 'Jharkhand', 1, 1, 0, NULL, NULL),
(16, 'Karnataka', 1, 1, 0, NULL, NULL),
(17, 'Kerala', 1, 1, 0, NULL, NULL),
(18, 'Lakshadweep', 1, 1, 0, NULL, NULL),
(19, 'Madhya Pradesh', 1, 1, 0, NULL, NULL),
(20, 'Maharashtra', 1, 1, 0, NULL, NULL),
(21, 'Manipur', 1, 1, 0, NULL, NULL),
(22, 'Meghalaya', 1, 1, 0, NULL, NULL),
(23, 'Mizoram', 1, 1, 0, NULL, NULL),
(24, 'Nagaland', 1, 1, 0, NULL, NULL),
(25, 'Odisha', 1, 1, 0, NULL, NULL),
(26, 'Puducherry', 1, 1, 0, NULL, NULL),
(27, 'Punjab', 1, 1, 0, NULL, NULL),
(28, 'Rajasthan', 1, 1, 0, NULL, NULL),
(29, 'Sikkim', 1, 1, 0, NULL, NULL),
(30, 'Tamil Nadu', 1, 1, 0, NULL, NULL),
(31, 'Telangana', 1, 1, 0, NULL, NULL),
(32, 'Tripura', 1, 1, 0, NULL, '2016-07-04 16:04:12'),
(33, 'Uttar Pradesh', 1, 1, 0, NULL, NULL),
(34, 'Uttarakhand', 1, 0, 0, NULL, '2016-06-22 11:10:58'),
(35, 'West Bengal', 1, 1, 0, NULL, '2016-07-04 15:14:17');

-- --------------------------------------------------------

--
-- Table structure for table `survey_numbers`
--

CREATE TABLE IF NOT EXISTS `survey_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `gut_survey_no` varchar(100) NOT NULL,
  `hissa_part_no` varchar(100) NOT NULL,
  `survey_no` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `survey_numbers`
--

INSERT INTO `survey_numbers` (`id`, `property_id`, `gut_survey_no`, `hissa_part_no`, `survey_no`, `created`, `modified`) VALUES
(24, 2, '120', '121', '120/121', '2016-06-15 15:57:41', '2016-06-15 15:57:41'),
(25, 3, '50', '51', '50/51', '2016-06-15 15:58:43', '2016-06-15 15:58:43'),
(26, 3, '60', '61', '60/61', '2016-06-15 15:58:43', '2016-06-15 15:58:43'),
(27, 4, '81', '82', '81/82', '2016-06-15 15:59:29', '2016-06-15 15:59:29'),
(30, 6, '1', '2', '1/2', '2016-06-17 16:00:11', '2016-06-17 16:00:11'),
(31, 6, '3', '4', '3/4', '2016-06-17 16:00:11', '2016-06-17 16:00:11'),
(32, 7, '6', '7', '6/7', '2016-06-17 16:02:28', '2016-06-17 16:02:28'),
(33, 7, '8', '9', '8/9', '2016-06-17 16:02:28', '2016-06-17 16:02:28'),
(41, 11, '50', '51', '50/51', '2016-06-18 12:32:33', '2016-06-18 12:32:33'),
(42, 10, '12', '13', '12/13', '2016-06-18 15:35:09', '2016-06-18 15:35:09'),
(43, 10, '19', '20', '19/20', '2016-06-18 15:35:09', '2016-06-18 15:35:09'),
(47, 5, '21', '22', '21/22', '2016-06-21 16:23:12', '2016-06-21 16:23:12'),
(56, 13, '65', '67', '65/67', '2016-07-04 11:36:54', '2016-07-04 11:36:54'),
(63, 9, '44', '45', '44/45', '2016-07-06 16:26:51', '2016-07-06 16:26:51'),
(64, 9, '46', '47', '46/47', '2016-07-06 16:26:51', '2016-07-06 16:26:51'),
(66, 8, '9', '10', '9/10', '2016-07-06 17:03:05', '2016-07-06 17:03:05'),
(69, 12, '101', '102', '101/102', '2016-07-06 17:04:02', '2016-07-06 17:04:02'),
(70, 12, '103', '104', '103/104', '2016-07-06 17:04:02', '2016-07-06 17:04:02'),
(72, 1, '1', '2', '1/2', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(73, 1, '3', '4', '3/4', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(74, 1, '5', '6', '5/6', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(75, 1, '101', '102', '101/102', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(76, 1, '201', '202', '201/202', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(77, 1, '1', '2', '1/2', '2016-07-09 13:20:44', '2016-07-09 13:20:44'),
(79, 14, '91', '92', '91/92', '2016-07-09 14:24:57', '2016-07-09 14:24:57');

-- --------------------------------------------------------

--
-- Table structure for table `talukas`
--

CREATE TABLE IF NOT EXISTS `talukas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_deleted` int(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `talukas`
--

INSERT INTO `talukas` (`id`, `name`, `city_id`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Alibag', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(2, 'Pen', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(3, 'Murud', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(4, 'Panvel', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(5, 'Uran', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(6, 'Karjat', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(7, 'Khalapur', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(8, 'Mangaon', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(9, 'Sudhagad', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(10, 'Roha', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(11, 'Tala', 5, 1, 0, '2016-06-15 15:26:33', '2016-06-15 15:26:33'),
(12, 'Mahad', 5, 1, 0, '2016-06-15 15:26:34', '2016-06-15 15:26:34'),
(13, 'Poladpur', 5, 1, 0, '2016-06-15 15:26:34', '2016-06-15 15:26:34'),
(14, 'Mhasla', 5, 1, 0, '2016-06-15 15:26:34', '2016-06-15 15:26:34'),
(15, 'Shrivardhan', 5, 1, 0, '2016-06-15 15:26:34', '2016-06-15 15:26:34'),
(16, 'Amravati', 10, 1, 0, '2016-06-15 15:42:44', '2016-06-15 15:42:44'),
(17, 'Achalpur', 10, 1, 0, '2016-06-15 15:42:44', '2016-06-15 15:42:44'),
(18, 'Warud', 10, 1, 0, '2016-06-15 15:42:44', '2016-06-15 15:42:44'),
(19, 'Chandurbazar', 10, 1, 0, '2016-06-15 15:42:44', '2016-06-15 15:42:44'),
(20, 'Dharni', 10, 1, 0, '2016-06-15 15:42:44', '2016-06-15 15:42:44'),
(21, 'Morshi', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(22, 'Daryapur', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(23, 'Anjangaon Surji', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(24, 'Dhamangaon Railway', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(25, 'Nandgaon-Khandeshwar', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(26, 'Chikhaldara', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(27, 'Bhatkuli', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(28, 'Teosa', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(29, 'Chandur Railway', 10, 1, 0, '2016-06-15 15:42:45', '2016-06-15 15:42:45'),
(30, 'Nagpur', 3, 1, 0, '2016-06-22 10:56:35', '2016-06-22 10:56:35'),
(31, 'Nashik', 5, 1, 0, '2016-07-09 18:49:58', '2016-07-09 18:49:58');

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE IF NOT EXISTS `tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `token` varchar(32) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`id`, `created`, `modified`, `token`, `data`) VALUES
(1, '2016-05-02 13:13:00', '2016-05-02 13:13:00', '0c5ada81d6', 'a:1:{s:4:"User";a:38:{s:2:"id";s:1:"1";s:7:"role_id";s:1:"1";s:5:"email";s:17:"admin@yopmail.com";s:8:"password";s:40:"f7eaf138a84300aa97dc46e27a53c38360f64fbe";s:7:"address";s:12:"test address";s:5:"state";s:0:"";s:4:"city";s:0:"";s:6:"taluka";s:0:"";s:7:"village";s:0:"";s:6:"mobile";s:1:"0";s:7:"idproof";s:0:"";s:12:"addressproof";s:0:"";s:8:"pvdetail";s:0:"";s:5:"pvdoc";s:0:"";s:5:"photo";s:0:"";s:7:"service";s:0:"";s:3:"dob";s:0:"";s:5:"cname";s:0:"";s:5:"phone";s:0:"";s:8:"relation";s:0:"";s:16:"relation_address";s:0:"";s:4:"dlno";s:0:"";s:10:"dl_expdate";s:0:"";s:6:"dl_doc";s:0:"";s:5:"pcono";s:0:"";s:10:"pcoexpdate";s:0:"";s:7:"pco_doc";s:0:"";s:6:"drnote";s:0:"";s:10:"last_login";s:19:"2016-05-02 11:08:28";s:13:"current_login";N;s:12:"is_logged_in";b:0;s:10:"ip_address";s:11:"192.168.1.7";s:9:"is_active";b:1;s:10:"is_deleted";b:0;s:13:"activate_date";s:19:"0000-00-00 00:00:00";s:7:"created";s:19:"2015-07-24 15:51:19";s:8:"modified";s:19:"2016-05-02 11:09:07";s:4:"name";s:6:"Admin ";}}'),
(2, '2016-05-02 13:17:21', '2016-05-02 13:17:21', '831b670a8d', 'a:1:{s:4:"User";a:38:{s:2:"id";s:1:"1";s:7:"role_id";s:1:"1";s:5:"email";s:17:"admin@yopmail.com";s:8:"password";s:40:"f7eaf138a84300aa97dc46e27a53c38360f64fbe";s:7:"address";s:12:"test address";s:5:"state";s:0:"";s:4:"city";s:0:"";s:6:"taluka";s:0:"";s:7:"village";s:0:"";s:6:"mobile";s:1:"0";s:7:"idproof";s:0:"";s:12:"addressproof";s:0:"";s:8:"pvdetail";s:0:"";s:5:"pvdoc";s:0:"";s:5:"photo";s:0:"";s:7:"service";s:0:"";s:3:"dob";s:0:"";s:5:"cname";s:0:"";s:5:"phone";s:0:"";s:8:"relation";s:0:"";s:16:"relation_address";s:0:"";s:4:"dlno";s:0:"";s:10:"dl_expdate";s:0:"";s:6:"dl_doc";s:0:"";s:5:"pcono";s:0:"";s:10:"pcoexpdate";s:0:"";s:7:"pco_doc";s:0:"";s:6:"drnote";s:0:"";s:10:"last_login";s:19:"2016-05-02 11:08:28";s:13:"current_login";N;s:12:"is_logged_in";b:0;s:10:"ip_address";s:11:"192.168.1.7";s:9:"is_active";b:1;s:10:"is_deleted";b:0;s:13:"activate_date";s:19:"0000-00-00 00:00:00";s:7:"created";s:19:"2015-07-24 15:51:19";s:8:"modified";s:19:"2016-05-02 11:09:07";s:4:"name";s:6:"Admin ";}}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(10) NOT NULL DEFAULT '0',
  `email` varchar(250) NOT NULL,
  `alt_email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `title` varchar(10) NOT NULL,
  `name` varchar(150) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `profession` int(3) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `alt_mobile_no` varchar(20) NOT NULL,
  `landline_no` varchar(50) NOT NULL,
  `country` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `taluka` varchar(255) NOT NULL,
  `village` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT '0',
  `package_id` int(11) NOT NULL,
  `package_start` date DEFAULT NULL,
  `package_end` date DEFAULT NULL,
  `terms_accepted` varchar(20) NOT NULL DEFAULT 'No',
  `last_login` datetime DEFAULT NULL,
  `current_login` datetime DEFAULT NULL,
  `is_logged_in` tinyint(1) DEFAULT '0',
  `ip_address` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>active/0=>de-active',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=>deleted/0=>not deleted',
  `activate_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL COMMENT '1=>deleted/0=>not deleted',
  `password_reset_token` varchar(255) DEFAULT NULL,
  `token_created_at` datetime DEFAULT NULL,
  `verify_token` varchar(200) NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `mobile_verify_code` varchar(200) NOT NULL,
  `mobile_verified` tinyint(1) NOT NULL DEFAULT '0',
  `registered_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_email_UNIQUE` (`email`),
  UNIQUE KEY `user_id_UNIQUE` (`id`),
  UNIQUE KEY `reset_password_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='stores records pertaining to site user' AUTO_INCREMENT=57 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `email`, `alt_email`, `password`, `title`, `name`, `middle_name`, `last_name`, `gender`, `profession`, `mobile_no`, `alt_mobile_no`, `landline_no`, `country`, `state`, `city`, `taluka`, `village`, `address`, `is_paid`, `package_id`, `package_start`, `package_end`, `terms_accepted`, `last_login`, `current_login`, `is_logged_in`, `ip_address`, `is_active`, `is_deleted`, `activate_date`, `created`, `modified`, `password_reset_token`, `token_created_at`, `verify_token`, `verified`, `mobile_verify_code`, `mobile_verified`, `registered_by`) VALUES
(1, 1, 'admin@yopmail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', '', 'Administrator', '', '', 'Male', 0, '1111111111', '', '', '0', '20', '', '', '', '', 0, 0, '0000-00-00', '0000-00-00', '', '2016-07-12 15:44:38', NULL, 0, '127.0.0.1', 1, 0, '0000-00-00 00:00:00', '2015-07-24 10:21:19', '2016-07-12 10:48:58', '9jw9ktc5', '2016-06-23 15:24:35', '', 0, '', 0, 1),
(2, 2, 'masood@gmail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', '', 'Mohammad', 'Masood', 'Shaikh', 'Male', 0, '8055732156', '', '0712 255075', '0', '20', '1', '', '', 'Shanti Nagar Nagpur - 02', 0, 0, '0000-00-00', '0000-00-00', '', '2016-07-12 16:19:12', NULL, 0, '127.0.0.1', 1, 0, '0000-00-00 00:00:00', '2016-06-06 11:43:26', '2016-07-12 10:59:49', 'ot2upp9z', '2016-06-23 15:24:23', '', 0, '', 0, 1),
(3, 7, 'coadmin@yopmail.com', 'coadmin@yopmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Co Administrator', '', '', 'Male', 0, '', '', '', '0', '0', '0', '', '', '', 0, 0, NULL, NULL, 'Yes', '2016-07-04 15:13:43', NULL, 0, '127.0.0.1', 1, 0, '0000-00-00 00:00:00', '2016-07-04 05:59:48', '2016-07-04 09:58:23', NULL, NULL, '', 1, '', 0, 1),
(4, 6, 'mohammadmasood01@gmail.com', 'mmm@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Mohammad', 'Masood', 'Shaikh', 'Male', 1, '8055736857', '9898989801', '0712 22247', '1', '20', '1', '', '', 'New Updated Address', 1, 3, '2016-06-07', '2016-09-05', '0', '2016-07-12 16:30:03', NULL, 1, '127.0.0.1', 1, 0, '0000-00-00 00:00:00', '2016-06-07 08:41:21', '2016-07-12 11:00:03', 'zc1f1k7k', '2016-06-29 16:17:43', '256452', 1, '693562', 1, 1),
(6, 6, 'masood01@gmail.com', 'mmm@gmail.com', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Mohammad', 'Masood', 'Shaikh', 'Male', 2, '8055736851', '9898989800', '0712 22247', '1', '20', '10', '', '', 'sdfds', 1, 1, '2016-06-09', '2016-06-09', 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-09 07:25:01', '2016-06-09 07:25:01', NULL, NULL, '', 0, '', 0, 1),
(7, 5, 'aaaaa@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'AAAAA', 'BBBBB', 'CCCCCC', 'Male', 0, '9865826358', '', '0712 369852', '', '20', '1', '', '', 'sdfdsfdfdsfdsf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 07:35:24', '2016-06-11 07:35:24', NULL, NULL, '', 0, '', 0, 1),
(8, 5, 'hemant@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Hemant', 'Raj', 'Khuran', 'Male', 0, '9638521470', '', '3652145897', '', '20', '1', '', '', 'sadsadasd', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 07:37:23', '2016-06-11 07:37:23', NULL, NULL, '', 0, '', 0, 1),
(9, 5, 'ssss@gmail.com', '', '531541ec827d2a55a8b457869f55ddff5afd82f9', 'Mr', 'SSSSSSS', 'sdsda', 'asdadad', 'Male', 0, '9336587412', '', '0172568952', '', '20', '1', '', '', 'asdfasdsfdsfdsf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 07:40:06', '2016-06-11 07:40:06', NULL, NULL, '', 0, '', 0, 1),
(10, 5, 'jjj@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'JJJJJ', 'kkk', 'll', 'Male', 0, '9632147852', '', '9632102545', '', '20', '1', '', '', 'dsfdsfdssdfsdfsdf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 07:41:44', '2016-06-11 07:41:44', NULL, NULL, '', 0, '', 0, 1),
(11, 5, 'aasasasasasas@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'asddasdsd', 'asddas', 'asd', 'Male', 0, '9632152012', '', '9632584120', '', '20', '1', '', '', 'sdddfsdfdsf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 07:44:58', '2016-06-11 07:44:58', NULL, NULL, '', 0, '', 0, 1),
(12, 5, 'zzzz@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mrs', 'ZZZ', 'YYYY', 'XXXX', 'Male', 0, '9637412580', '', '0712 369582', '', '20', '1', '', '', 'sdsdsad', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 07:49:36', '2016-06-11 07:49:36', NULL, NULL, '', 0, '', 0, 0),
(13, 5, 'aazzzz@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'ASASA', 'BSBSB', 'CSCSC', 'Male', 0, '9638741200', '', '0712 365201', '', '20', '1', '', '', 'asdassadasdas', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-11 10:54:26', '2016-06-11 10:54:26', NULL, NULL, '', 0, '', 0, 1),
(14, 5, 'aaaa@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'aqsa', 'ASDFSA', 'ADF', 'Male', 0, '1236549870', '', '3695210245', '', '20', '1', '', '', 'dffdf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-14 09:42:54', '2016-06-21 06:10:50', NULL, NULL, '', 0, '', 0, 0),
(15, 5, 'asdasdas@yahoo.in', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mrs', 'aa', 'dsds', 'dsfdsf', 'Male', 0, '9632587456', '', '3652654658', '', '20', '1', '', '', 'sddfdsfds', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-14 09:44:19', '2016-06-14 09:44:19', NULL, NULL, '', 0, '', 0, 1),
(16, 5, 'kunal@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Kunal', 'Atul', 'Mishra', 'Male', 0, '9852654123', '', '3658521420', '', '20', '1', '', '', 'sdfdf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-14 09:52:29', '2016-06-14 09:52:29', NULL, NULL, '', 0, '', 0, 1),
(17, 5, 'kkk@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'fff', 'nnn', 'kkk', 'Male', 0, '9632585210', '', '6541236580', '', '20', '1', '', '', 'fddfdssfdsfsd', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-14 10:13:31', '2016-06-14 10:13:31', NULL, NULL, '', 0, '', 0, 1),
(18, 2, 'ykk@gmail.com', '', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', '', 'yogesh', 'kailash', 'kumar', 'Male', 0, '9632587410', '', '1234560251', '', '20', '1', '', '', 'sdffdf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-15 07:20:27', '2016-07-04 10:34:04', NULL, NULL, '', 0, '', 0, 1),
(19, 6, 'arun@gmail.com', 'arn@gmail.com', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Arun', 'Anil', 'Kumar', 'Male', 1, '9632541203', '1236547914', '0174258621', '1', '20', '10', '', '', 'asdsffdssda', 1, 4, '2016-06-15', '2016-12-12', 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-15 10:26:40', '2016-06-15 10:49:03', NULL, NULL, '', 0, '', 0, 1),
(20, 6, 'manish@gmail.com', 'arn@gmail.com', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Manish', 'Suresh', 'Patil', 'Male', 1, '9214587562', '3214587410', '2154789526', '1', '20', '3', '', '', 'dcfdfdsf', 1, 3, '2016-06-15', '2016-09-13', 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-15 10:48:36', '2016-06-15 11:07:01', NULL, NULL, '', 0, '', 0, 1),
(26, 6, 'ajay@gmail.com', 'ajay2@gmail.com', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Ajay', 'Manish', 'Khurana', 'Male', 2, '9632212302', '3366552211', '3322114455', '1', '20', '3', '', '', 'sdcddssffd', 1, 2, '2016-06-16', '2016-07-16', 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-16 11:19:36', '2016-06-16 11:19:36', NULL, NULL, '', 0, '', 0, 1),
(27, 6, 'masood121@gmail.com', 'mmmsssddd@gmail.com', 'f7eaf138a84300aa97dc46e27a53c38360f64fbe', 'Mr', 'Masood', 'Raqfique', 'Shaikh', 'Male', 1, '9658214520', '', '', '1', '20', '3', '', '', 'Shanati Nagar', 1, 1, '2016-06-17', '2016-06-17', 'Yes', '2016-06-17 11:29:54', NULL, 0, '127.0.0.1', 1, 0, '0000-00-00 00:00:00', '2016-06-17 05:05:18', '2016-06-17 06:39:03', 'jnwxpyks', NULL, '', 0, '', 0, 1),
(29, 6, 'varun22@gmail.com', 'vsk22@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Varun', 'Shashi', 'Khatri', 'Male', 2, '9890420520', '9890520420', '0712558695', '1', '20', '3', '', '', 'Kalmeshwar', 1, 1, '2016-06-20', '2016-06-20', 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-20 08:13:03', '2016-06-20 08:19:33', NULL, NULL, '', 1, '', 0, 1),
(30, 6, 'varun11@gmail.com', 'vsk111@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Varun1', 'Shashi1', 'Khatri1', 'Female', 1, '9890420521', '9890520421', '0712558696', '1', '20', '3', '', '', 'Khamla', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-20 08:25:32', '2016-06-21 06:16:03', NULL, NULL, 'dq852mfn', 0, '', 0, 1),
(31, 6, 'bhushan@gmail.com', 'bsn@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Bhushan', 'Sushil', 'Agarwal', 'Male', 2, '9625412011', '9522558741', '0712556623', '1', '20', '2', '', '', 'Shankar Nagar', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-21 06:03:22', '2016-06-21 06:19:27', NULL, NULL, 'kfa4cl1f', 0, '', 0, 1),
(32, 2, 'jayant@gmail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', '', 'Jayant', 'Hemant', 'Gondane', 'Male', 0, '9525212232', '', '0712336655', '', '20', '3', '', '', 'Ravi Nagar', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-21 06:08:18', '2016-06-21 06:09:56', NULL, NULL, '', 0, '', 0, 1),
(33, 6, 'abc@gmail.com', 'cba@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'AAA', 'BBB', 'CCC', 'Male', 1, '9876543210', '9012345678', '0721252627', '1', '20', '3', '', '', 'AAAAA', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-22 05:00:37', '2016-06-22 05:06:27', NULL, NULL, '', 1, '', 0, 1),
(34, 6, 'user@gmail.com', 'useralt@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'AAA', 'BBB', 'CCC', 'Male', 2, '9631478525', '9631478511', '0712365214', '1', '20', '3', '', '', 'xcxzczxczxczx', 1, 2, '2016-06-22', '2016-07-22', 'Yes', NULL, NULL, 0, NULL, 0, 0, '0000-00-00 00:00:00', '2016-06-22 08:58:51', '2016-07-04 06:01:17', NULL, NULL, '3rgv8vuo', 0, '', 0, 1),
(35, 6, 'sssnn@gmail.com', 'asdd@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mrs', 'aa', 'dsfdsfds', 'sdfdsfsdd', 'Male', 2, '6524562120', '2033656985', '07126985241', '1', '20', '3', '', '', 'zdfcz sadddsafdsfsdf', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 0, 0, '0000-00-00 00:00:00', '2016-06-23 08:16:27', '2016-07-04 06:01:18', NULL, NULL, 'b2m9fukj', 0, '', 0, 1),
(36, 6, 'sheetal@gmail.com', 'svj@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mrs', 'Shital', 'Vijay', 'Sharma', 'Female', 3, '9632587422', '6953214520', '0712654563', '1', '20', '3', '', '', 'asddsadasd asda asdasd', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 0, 0, '0000-00-00 00:00:00', '2016-06-23 08:21:58', '2016-07-04 06:01:19', NULL, NULL, '', 1, '', 0, 0),
(37, 6, 'xyz@gmail.com', 'abcxyz@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'XXX', 'YYY', 'ZZZ', 'Male', 1, '9212121210', '2690221220', '0712365266', '1', '20', '3', '', '', 'addas adasddadasdad', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-23 08:28:02', '2016-06-23 08:39:11', NULL, NULL, '', 1, '', 0, 0),
(38, 6, 'ssslll@gmail.com', 'sssbcxyz@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'sdsd', 'sadsds', 'sadsadds', 'Male', 1, '9587421562', '6598521450', '0124568952', '1', '20', '3', '', '', 'asddsdsfdfdsfdsfdfdsfsf', 0, 1, NULL, NULL, 'Yes', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-06-23 08:40:52', '2016-06-23 08:40:52', NULL, NULL, 'mtb3bdz6', 0, '', 0, 0),
(39, 6, 'suresh@gmail.com', 'aaa@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Suresh', 'Kapil', 'Sahu', 'Male', 1, '9636852147', '2586523212', '', '1', '20', '3', '', '', 'sdfsdfdsfsd fsdfsdfs', 0, 1, NULL, NULL, 'Yes', '2016-06-27 11:23:31', NULL, 0, '127.0.0.1', 1, 0, '0000-00-00 00:00:00', '2016-06-23 11:16:55', '2016-07-09 11:52:01', NULL, NULL, '8utcni2t', 1, '753674', 1, 1),
(45, 5, 'aaarrr@gmail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Pankaj', '', '', 'Male', 0, '', '', '', '', '20', '18', '', '', 'Sdsasdsadsad', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:03:50', '2016-07-02 08:30:45', NULL, NULL, '', 0, '', 0, 1),
(46, 5, 'gfcms@fakemail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'sdasdsadasdsadsadasd', '', '', 'Male', 0, '', '', '', '', '20', '3', '', '', 'asdsad', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:32:18', '2016-07-02 08:32:18', NULL, NULL, '', 0, '', 0, 1),
(47, 5, 'f64s1@fakemail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'qqqqqqqq', '', '', 'Male', 0, '', '', '', '', '20', '3', '', '', 'sdff', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:32:41', '2016-07-02 08:32:41', NULL, NULL, '', 0, '', 0, 1),
(48, 5, '790q3@fakemail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'sadadsasadasdsad', '', '', 'Male', 0, '', '', '', '', '20', '3', '', '', 'dasds', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:52:56', '2016-07-02 08:52:56', NULL, NULL, '', 0, '', 0, 1),
(49, 5, 'umr3z@fakemail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'ssdszssddsasd', '', '', 'Male', 0, '', '', '', '', '20', '3', '', '', 'saddsa', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:55:24', '2016-07-02 08:55:24', NULL, NULL, '', 0, '', 0, 1),
(50, 5, 'f6jjm@fakemail.com', 'aall@ggsgf.dds', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'Pankaj', 'Uday', 'sads', 'Male', 0, '', '8899665585', '0785258652', '', '20', '3', '', '', 'ds', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:56:34', '2016-07-02 08:56:34', NULL, NULL, '', 0, '', 0, 1),
(51, 5, 'zap6x@fakemail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'skkakakakalalal', '', '', 'Male', 0, '', '', '', '', '20', '11', '', '', 'dfdsdf', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 08:59:27', '2016-07-02 08:59:27', NULL, NULL, '', 0, '', 0, 1),
(52, 5, 'o38si@fakemail.com', 'asdssds@gmail.com', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'aa', 'bbbbaaa', 'sss', 'Male', 0, '', '9988552263', '0124585695', '', '20', '3', '', '', 'sdfds', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 09:02:36', '2016-07-02 10:57:08', NULL, NULL, '', 0, '', 0, 1),
(53, 5, 'r41hl@fakemail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', 'Mr', 'asasasassa', 'sdsdad', 'sadsds', 'Male', 0, '', '', '', '', '20', '3', '', '', 'ssss', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-02 09:05:23', '2016-07-09 13:34:12', NULL, NULL, '', 0, '', 0, 1),
(54, 2, 'abcc@gmail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', '', 'a', 'b', 'c', 'Male', 0, '9898989898', '', '0712656569', '', '20', '3', '', '', 'asasas', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-04 05:37:03', '2016-07-04 10:33:57', NULL, NULL, '', 0, '', 0, 1),
(56, 2, 'jayantgondane@gmail.com', '', '944536cfa6511bf0d5e2a5152d33e554246465df', '', 'Jayant', 'Harish', 'Gondane', 'Male', 0, '9372724653', '', '0223652156', '', '20', '3', '', '', 'sdfddffsd dfsd dff', 0, 0, NULL, NULL, 'No', NULL, NULL, 0, NULL, 1, 0, '0000-00-00 00:00:00', '2016-07-05 05:31:00', '2016-07-05 05:31:00', NULL, NULL, '', 0, '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `villages`
--

CREATE TABLE IF NOT EXISTS `villages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `taluka_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_deleted` int(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `villages`
--

INSERT INTO `villages` (`id`, `name`, `taluka_id`, `is_active`, `is_deleted`, `created`, `modified`) VALUES
(1, 'Agarkot', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(2, 'Agarsure', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(3, 'Akshi', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(4, 'Ambeghar', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(5, 'Andoshi', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(6, 'Awas', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(7, 'Aweti', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(8, 'Bagmala', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(9, 'Bahirichapada', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(10, 'Bahirole', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(11, 'Bamangaon', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(12, 'Bamanoli', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(13, 'Bamansure', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(14, 'Bapale', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(15, 'Belkade', 1, 1, 0, '2016-06-15 15:36:35', '2016-06-15 15:36:35'),
(16, 'Ambada Kandari', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(17, 'Aregaon', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(18, 'Asatpur', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(19, 'Aurangpur', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(20, 'Bag Ambada', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(21, 'Balegaon', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(22, 'Belkheda', 17, 1, 0, '2016-06-15 15:51:52', '2016-06-15 15:51:52'),
(23, 'Beni', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(24, 'Bhilona', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(25, 'Bhopapur', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(26, 'Bhugaon', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(27, 'Bordi', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(28, 'Borgaon Dori', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(29, 'Borgaon Peth', 17, 1, 0, '2016-06-15 15:51:53', '2016-06-15 15:51:53'),
(30, 'Nagpur', 30, 1, 0, '2016-06-22 10:56:47', '2016-06-22 10:56:47'),
(31, 'Amravati', 16, 1, 0, '2016-06-22 10:57:38', '2016-06-22 10:57:38'),
(32, 'Ner', 21, 1, 0, '2016-06-22 12:13:35', '2016-06-22 12:13:35'),
(33, 'aaa', 30, 1, 0, '2016-06-22 12:48:58', '2016-06-22 12:48:58'),
(34, 'bbbbb', 30, 1, 0, '2016-06-22 12:49:23', '2016-06-22 12:49:23'),
(35, 'fdfdfdf', 30, 1, 0, '2016-06-22 12:52:27', '2016-06-22 12:52:27'),
(36, 'aaafdfdfdf', 30, 1, 0, '2016-06-22 12:52:35', '2016-06-22 12:52:35'),
(37, 'ssdsdds', 30, 1, 0, '2016-06-22 12:53:01', '2016-06-22 12:53:01'),
(38, 'sdsadsd', 30, 1, 0, '2016-06-22 12:54:36', '2016-06-22 12:54:36'),
(39, 'aaaasdaasdsad', 30, 1, 0, '2016-06-22 12:57:38', '2016-06-22 12:57:38'),
(40, 'asdsasa', 21, 1, 0, '2016-06-17 00:00:00', '2016-06-27 00:00:00'),
(41, 'Nashik', 31, 1, 0, '2016-07-09 18:50:13', '2016-07-09 18:50:13');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
